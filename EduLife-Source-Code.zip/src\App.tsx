import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { ToastProvider } from './context/ToastContext';
import { AppDataProvider } from './context/AppDataContext';
import { AppLayout } from './components/layout/AppLayout';

import { HomePage } from './pages/HomePage';
import { DashboardPage } from './pages/DashboardPage';
import { StudyPlannerPage } from './pages/StudyPlannerPage';
import { NotesPage } from './pages/NotesPage';
import { AssignmentsPage } from './pages/AssignmentsPage';
import { ExamPreparationPage } from './pages/ExamPreparationPage';
import { EducationResourcesPage } from './pages/EducationResourcesPage';
import { StudentCommunityPage } from './pages/StudentCommunityPage';
import { CareerInternshipsPage } from './pages/CareerInternshipsPage';
import { ProfileSettingsPage } from './pages/ProfileSettingsPage';

export const App: React.FC = () => {
  return (
    <ThemeProvider>
      <ToastProvider>
        <AppDataProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<AppLayout />}>
                <Route index element={<HomePage />} />
                <Route path="dashboard" element={<DashboardPage />} />
                <Route path="planner" element={<StudyPlannerPage />} />
                <Route path="notes" element={<NotesPage />} />
                <Route path="assignments" element={<AssignmentsPage />} />
                <Route path="exams" element={<ExamPreparationPage />} />
                <Route path="resources" element={<EducationResourcesPage />} />
                <Route path="community" element={<StudentCommunityPage />} />
                <Route path="career" element={<CareerInternshipsPage />} />
                <Route path="settings" element={<ProfileSettingsPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Route>
            </Routes>
          </BrowserRouter>
        </AppDataProvider>
      </ToastProvider>
    </ThemeProvider>
  );
};

export default App;
