import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, ArrowRight, Flame, Target } from 'lucide-react';
import { useAppData } from '../../context/AppDataContext';

export const ExamCountdownCard: React.FC = () => {
  const { exams } = useAppData();

  // Find nearest exam
  const sortedExams = [...exams].sort((a, b) => a.date.localeCompare(b.date));
  const nextExam = sortedExams[0];

  if (!nextExam) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm flex flex-col items-center justify-center text-center">
        <p className="text-xs text-slate-400">No exams scheduled currently.</p>
      </div>
    );
  }

  // Calculate days remaining
  const examDate = new Date(nextExam.date);
  const today = new Date();
  const diffTime = examDate.getTime() - today.getTime();
  const diffDays = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));

  const completedTopics = nextExam.topics.filter((t) => t.completed).length;
  const totalTopics = nextExam.topics.length;
  const syllabusPercent = totalTopics > 0 ? Math.round((completedTopics / totalTopics) * 100) : 0;

  return (
    <div className="bg-gradient-to-br from-brand-600 to-violet-700 text-white rounded-3xl p-6 shadow-lg shadow-brand-500/20 flex flex-col justify-between relative overflow-hidden">
      {/* Background ambient pattern */}
      <div className="absolute top-0 right-0 -mr-8 -mt-8 w-36 h-36 bg-white/10 rounded-full blur-2xl pointer-events-none" />

      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-white/20 backdrop-blur-md">
              <Clock className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-[10px] font-bold tracking-wider uppercase text-blue-200">
                Exam Countdown
              </span>
              <h3 className="text-sm font-bold text-white leading-tight">
                {nextExam.subject}
              </h3>
            </div>
          </div>
          <Link
            to="/exams"
            className="text-xs font-semibold text-blue-100 hover:text-white flex items-center space-x-1"
          >
            <span>Prep Hub</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {/* Countdown big numbers */}
        <div className="grid grid-cols-3 gap-2 my-4 text-center">
          <div className="p-2.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10">
            <span className="text-2xl font-black">{diffDays}</span>
            <p className="text-[10px] uppercase font-semibold text-blue-200 mt-0.5">Days Left</p>
          </div>
          <div className="p-2.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10">
            <span className="text-2xl font-black">{syllabusPercent}%</span>
            <p className="text-[10px] uppercase font-semibold text-blue-200 mt-0.5">Syllabus</p>
          </div>
          <div className="p-2.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10">
            <span className="text-2xl font-black">{totalTopics - completedTopics}</span>
            <p className="text-[10px] uppercase font-semibold text-blue-200 mt-0.5">Topics Left</p>
          </div>
        </div>

        {/* Syllabus completion progress bar */}
        <div className="space-y-1.5 mt-2">
          <div className="flex justify-between text-xs font-medium text-blue-100">
            <span className="flex items-center gap-1">
              <Target className="w-3.5 h-3.5" />
              <span>Revision Progress</span>
            </span>
            <span>{completedTopics}/{totalTopics} Covered</span>
          </div>
          <div className="w-full h-2 rounded-full bg-black/20 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-300 to-emerald-300 transition-all duration-500 rounded-full"
              style={{ width: `${syllabusPercent}%` }}
            />
          </div>
        </div>
      </div>

      <div className="mt-4 pt-3 border-t border-white/15 text-[11px] text-blue-100 flex items-center justify-between">
        <span className="truncate">{nextExam.title}</span>
        <span className="font-semibold px-2 py-0.5 rounded-full bg-white/20">
          {nextExam.date}
        </span>
      </div>
    </div>
  );
};
