import React, { useState } from 'react';
import {
  Calendar,
  CheckCircle2,
  Circle,
  Plus,
  Trash2,
  Edit2,
  Filter,
  Sparkles,
  BookOpen,
  Timer
} from 'lucide-react';
import { useAppData } from '../context/AppDataContext';
import { useToast } from '../context/ToastContext';
import { PomodoroTimer } from '../components/tools/PomodoroTimer';
import { TimetableGrid } from '../components/tools/TimetableGrid';
import { WellnessWidget } from '../components/tools/WellnessWidget';
import { Modal } from '../components/common/Modal';
import { Task, Priority, SubjectProgress } from '../types';

export const StudyPlannerPage: React.FC = () => {
  const {
    tasks,
    addTask,
    toggleTask,
    updateTask,
    deleteTask,
    subjectProgress,
    updateSubjectProgress
  } = useAppData();
  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<'all' | 'timetable' | 'pomodoro' | 'tasks'>('all');
  const [taskFilter, setTaskFilter] = useState<'all' | 'active' | 'completed'>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');

  // Task Modal state
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [taskTitle, setTaskTitle] = useState('');
  const [taskSubject, setTaskSubject] = useState('');
  const [taskDueDate, setTaskDueDate] = useState('');
  const [taskPriority, setTaskPriority] = useState<Priority>('medium');
  const [taskMinutes, setTaskMinutes] = useState(45);

  // Edit Subject Modal state
  const [isSubjectModalOpen, setIsSubjectModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<SubjectProgress | null>(null);
  const [subAttendance, setSubAttendance] = useState(85);
  const [subSyllabus, setSubSyllabus] = useState(70);
  const [subTargetGrade, setSubTargetGrade] = useState('A');

  const openAddTaskModal = () => {
    setEditingTask(null);
    setTaskTitle('');
    setTaskSubject('Data Structures & Algorithms');
    setTaskDueDate(new Date().toISOString().split('T')[0]);
    setTaskPriority('medium');
    setTaskMinutes(45);
    setIsTaskModalOpen(true);
  };

  const openEditTaskModal = (task: Task) => {
    setEditingTask(task);
    setTaskTitle(task.title);
    setTaskSubject(task.subject);
    setTaskDueDate(task.dueDate);
    setTaskPriority(task.priority);
    setTaskMinutes(task.estimatedMinutes || 45);
    setIsTaskModalOpen(true);
  };

  const handleSaveTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;

    if (editingTask) {
      updateTask({
        ...editingTask,
        title: taskTitle,
        subject: taskSubject,
        dueDate: taskDueDate,
        priority: taskPriority,
        estimatedMinutes: Number(taskMinutes)
      });
      showToast('Task updated successfully!', 'success');
    } else {
      addTask({
        title: taskTitle,
        subject: taskSubject,
        dueDate: taskDueDate,
        priority: taskPriority,
        completed: false,
        estimatedMinutes: Number(taskMinutes)
      });
      showToast('New study task added!', 'success');
    }
    setIsTaskModalOpen(false);
  };

  const openEditSubjectModal = (subj: SubjectProgress) => {
    setEditingSubject(subj);
    setSubAttendance(subj.attendance);
    setSubSyllabus(subj.syllabusCompleted);
    setSubTargetGrade(subj.targetGrade);
    setIsSubjectModalOpen(true);
  };

  const handleSaveSubject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSubject) return;

    updateSubjectProgress({
      ...editingSubject,
      attendance: Number(subAttendance),
      syllabusCompleted: Number(subSyllabus),
      targetGrade: subTargetGrade
    });

    showToast(`Updated progress for ${editingSubject.name}`, 'success');
    setIsSubjectModalOpen(false);
  };

  // Filter tasks
  const filteredTasks = tasks.filter((t) => {
    if (taskFilter === 'active' && t.completed) return false;
    if (taskFilter === 'completed' && !t.completed) return false;
    if (priorityFilter !== 'all' && t.priority !== priorityFilter) return false;
    return true;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2.5">
            <Calendar className="w-8 h-8 text-brand-600" />
            Study Planner & Tools
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Organize your study blocks, crush focus sessions with Pomodoro, and manage class schedules.
          </p>
        </div>

        {/* View switcher tabs */}
        <div className="flex items-center space-x-1 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800/80 self-start sm:self-auto">
          {(['all', 'timetable', 'pomodoro', 'tasks'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all ${
                activeTab === tab
                  ? 'bg-white dark:bg-slate-700 text-brand-600 dark:text-brand-300 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {tab === 'all' ? 'All Tools' : tab}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content Layout based on activeTab */}
      {(activeTab === 'all' || activeTab === 'pomodoro') && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <PomodoroTimer />
          </div>
          <div>
            <WellnessWidget />
          </div>
        </div>
      )}

      {(activeTab === 'all' || activeTab === 'timetable') && (
        <div>
          <TimetableGrid />
        </div>
      )}

      {(activeTab === 'all' || activeTab === 'tasks') && (
        /* Task Manager Section */
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                Study Tasks & Action Items
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Track assignments, problem sets, and review reading list.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Status filter */}
              <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-medium">
                {(['all', 'active', 'completed'] as const).map((f) => (
                  <button
                    key={f}
                    onClick={() => setTaskFilter(f)}
                    className={`px-2.5 py-1 rounded-lg capitalize transition-colors ${
                      taskFilter === f
                        ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm font-semibold'
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>

              {/* Priority filter */}
              <select
                value={priorityFilter}
                onChange={(e) => setPriorityFilter(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 outline-none"
              >
                <option value="all">All Priorities</option>
                <option value="high">High Priority</option>
                <option value="medium">Medium Priority</option>
                <option value="low">Low Priority</option>
              </select>

              <button
                onClick={openAddTaskModal}
                className="flex items-center space-x-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-brand-600 hover:bg-brand-500 rounded-xl shadow-sm transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>Add Task</span>
              </button>
            </div>
          </div>

          {/* Task list items */}
          <div className="space-y-2.5">
            {filteredTasks.length === 0 ? (
              <div className="text-center py-10 text-slate-400">
                <p className="text-sm font-medium">No tasks found for the selected filter.</p>
              </div>
            ) : (
              filteredTasks.map((task) => (
                <div
                  key={task.id}
                  className={`p-4 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                    task.completed
                      ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/40 opacity-75'
                      : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-800 hover:border-brand-300'
                  }`}
                >
                  <div
                    onClick={() => toggleTask(task.id)}
                    className="flex items-center space-x-3.5 cursor-pointer flex-1 min-w-0"
                  >
                    {task.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-400 hover:text-brand-500 transition-colors shrink-0" />
                    )}
                    <div className="min-w-0">
                      <h4
                        className={`text-sm font-bold truncate ${
                          task.completed
                            ? 'line-through text-slate-400 dark:text-slate-500'
                            : 'text-slate-900 dark:text-slate-100'
                        }`}
                      >
                        {task.title}
                      </h4>
                      <div className="flex items-center space-x-3 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        <span className="font-medium text-brand-600 dark:text-brand-400">
                          {task.subject}
                        </span>
                        <span>•</span>
                        <span>Due: {task.dueDate}</span>
                        {task.estimatedMinutes && (
                          <>
                            <span>•</span>
                            <span>{task.estimatedMinutes} mins</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <span
                      className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-md ${
                        task.priority === 'high'
                          ? 'bg-rose-100 text-rose-700 dark:bg-rose-900/50 dark:text-rose-300'
                          : task.priority === 'medium'
                          ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-300'
                          : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {task.priority}
                    </span>

                    <button
                      onClick={() => openEditTaskModal(task)}
                      className="p-1.5 text-slate-400 hover:text-brand-600 dark:hover:text-brand-400 transition-colors"
                      title="Edit Task"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        deleteTask(task.id);
                        showToast('Task deleted', 'info');
                      }}
                      className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 transition-colors"
                      title="Delete Task"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Subject-Wise Progress Table with Quick Edit */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-indigo-500" />
              Coursework & Syllabus Tracking
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Click "Update" on any subject to adjust your study completion or target grade.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 uppercase tracking-wider">
                <th className="py-3 px-4 font-semibold">Course</th>
                <th className="py-3 px-4 font-semibold">Syllabus Covered</th>
                <th className="py-3 px-4 font-semibold">Attendance</th>
                <th className="py-3 px-4 font-semibold">Studied</th>
                <th className="py-3 px-4 font-semibold">Target Grade</th>
                <th className="py-3 px-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {subjectProgress.map((subj) => (
                <tr key={subj.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4">
                    <span className="font-bold text-slate-800 dark:text-slate-100">{subj.name}</span>
                    <span className="block text-[11px] text-slate-400">{subj.code}</span>
                  </td>
                  <td className="py-3.5 px-4 w-44">
                    <div className="flex items-center space-x-2">
                      <div className="flex-1 h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{ width: `${subj.syllabusCompleted}%`, backgroundColor: subj.color }}
                        />
                      </div>
                      <span className="font-semibold text-slate-700 dark:text-slate-300">
                        {subj.syllabusCompleted}%
                      </span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-emerald-600 dark:text-emerald-400">
                    {subj.attendance}%
                  </td>
                  <td className="py-3.5 px-4 font-medium text-slate-600 dark:text-slate-300">
                    {subj.hoursStudied} hrs
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded-md font-bold bg-brand-50 dark:bg-brand-950/60 text-brand-600 dark:text-brand-300">
                      {subj.targetGrade}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => openEditSubjectModal(subj)}
                      className="px-3 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-semibold"
                    >
                      Update
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Task Modal */}
      <Modal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
        title={editingTask ? 'Edit Study Task' : 'Create New Study Task'}
      >
        <form onSubmit={handleSaveTask} className="space-y-4 text-left">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Task Title *
            </label>
            <input
              type="text"
              required
              value={taskTitle}
              onChange={(e) => setTaskTitle(e.target.value)}
              placeholder="e.g. Implement Dijkstra’s Algorithm in Python"
              className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Course / Subject
              </label>
              <input
                type="text"
                value={taskSubject}
                onChange={(e) => setTaskSubject(e.target.value)}
                placeholder="e.g. Data Structures"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Due Date
              </label>
              <input
                type="date"
                value={taskDueDate}
                onChange={(e) => setTaskDueDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Priority
              </label>
              <select
                value={taskPriority}
                onChange={(e) => setTaskPriority(e.target.value as Priority)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              >
                <option value="low">Low Priority</option>
                <option value="medium">Medium Priority</option>
                <option value="high">High Priority</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Estimated Minutes
              </label>
              <input
                type="number"
                min="5"
                max="360"
                value={taskMinutes}
                onChange={(e) => setTaskMinutes(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsTaskModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-brand-600 hover:bg-brand-500 rounded-xl shadow-sm"
            >
              Save Task
            </button>
          </div>
        </form>
      </Modal>

      {/* Edit Subject Modal */}
      <Modal
        isOpen={isSubjectModalOpen}
        onClose={() => setIsSubjectModalOpen(false)}
        title={editingSubject ? `Update ${editingSubject.name}` : 'Update Subject'}
      >
        <form onSubmit={handleSaveSubject} className="space-y-4 text-left">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Syllabus Completed (%)
            </label>
            <div className="flex items-center space-x-3">
              <input
                type="range"
                min="0"
                max="100"
                value={subSyllabus}
                onChange={(e) => setSubSyllabus(Number(e.target.value))}
                className="flex-1 accent-brand-600"
              />
              <span className="font-bold text-sm w-12 text-right">{subSyllabus}%</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Attendance Record (%)
            </label>
            <div className="flex items-center space-x-3">
              <input
                type="range"
                min="0"
                max="100"
                value={subAttendance}
                onChange={(e) => setSubAttendance(Number(e.target.value))}
                className="flex-1 accent-emerald-600"
              />
              <span className="font-bold text-sm w-12 text-right">{subAttendance}%</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Target Semester Grade
            </label>
            <select
              value={subTargetGrade}
              onChange={(e) => setSubTargetGrade(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
            >
              <option value="A+">A+ (4.0)</option>
              <option value="A">A (4.0)</option>
              <option value="A-">A- (3.7)</option>
              <option value="B+">B+ (3.3)</option>
              <option value="B">B (3.0)</option>
            </select>
          </div>

          <div className="flex justify-end space-x-2 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsSubjectModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-brand-600 hover:bg-brand-500 rounded-xl shadow-sm"
            >
              Save Changes
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
