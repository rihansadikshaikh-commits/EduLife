import React, { useState, useEffect } from 'react';
import { Heart, Wind, Play, Pause, RefreshCw, Sun, Smile } from 'lucide-react';

export const WellnessWidget: React.FC = () => {
  const [breathingActive, setBreathingActive] = useState(false);
  const [phase, setPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');
  const [secondsLeft, setSecondsLeft] = useState(4);
  const [cyclesCompleted, setCyclesCompleted] = useState(0);

  useEffect(() => {
    let timer: ReturnType<typeof setInterval>;
    if (breathingActive) {
      timer = setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            if (phase === 'Inhale') {
              setPhase('Hold');
              return 4;
            } else if (phase === 'Hold') {
              setPhase('Exhale');
              return 4;
            } else {
              setPhase('Inhale');
              setCyclesCompleted((c) => c + 1);
              return 4;
            }
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [breathingActive, phase]);

  const toggleBreathing = () => {
    if (!breathingActive) {
      setPhase('Inhale');
      setSecondsLeft(4);
    }
    setBreathingActive(!breathingActive);
  };

  return (
    <div className="bg-gradient-to-br from-violet-500/10 via-brand-500/5 to-teal-500/10 border border-violet-200 dark:border-violet-900/50 rounded-3xl p-6 shadow-sm relative overflow-hidden">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <div className="p-2 rounded-xl bg-violet-500 text-white shadow-sm">
            <Heart className="w-4 h-4" />
          </div>
          <div>
            <h4 className="font-bold text-sm text-slate-800 dark:text-slate-100">Mindful Break & De-Stress</h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">Box Breathing 4-4-4 Technique</p>
          </div>
        </div>
        <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-violet-100 dark:bg-violet-900/60 text-violet-700 dark:text-violet-300">
          Cycles: {cyclesCompleted}
        </span>
      </div>

      {/* Visual Breathing Orb */}
      <div className="flex flex-col items-center justify-center my-6">
        <div
          className={`w-28 h-28 rounded-full flex flex-col items-center justify-center transition-all duration-1000 transform ${
            breathingActive && phase === 'Inhale'
              ? 'scale-125 bg-gradient-to-tr from-brand-400 to-violet-500 shadow-xl shadow-brand-500/30'
              : breathingActive && phase === 'Hold'
              ? 'scale-110 bg-gradient-to-tr from-amber-400 to-orange-500 shadow-xl shadow-amber-500/30'
              : breathingActive && phase === 'Exhale'
              ? 'scale-90 bg-gradient-to-tr from-teal-400 to-emerald-500 shadow-md'
              : 'scale-100 bg-gradient-to-tr from-brand-500 to-violet-600 shadow-md'
          } text-white`}
        >
          <Wind className="w-6 h-6 mb-1 opacity-90 animate-pulse" />
          <span className="text-sm font-bold tracking-wide">{breathingActive ? phase : 'Ready'}</span>
          {breathingActive && <span className="text-xs font-mono">{secondsLeft}s</span>}
        </div>

        <button
          onClick={toggleBreathing}
          className="mt-6 flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-semibold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 shadow-sm hover:bg-slate-50 transition-all"
        >
          {breathingActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 text-brand-600" />}
          <span>{breathingActive ? 'Pause Exercise' : 'Start 2-Min Reset'}</span>
        </button>
      </div>

      {/* Wellness Tip */}
      <div className="bg-white/80 dark:bg-slate-900/80 rounded-2xl p-3 border border-slate-200/60 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 flex items-start space-x-2.5">
        <Smile className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
        <p>
          <strong>Student Wellness Tip:</strong> Take 20 seconds every 20 minutes to look at an object 20 feet away to relax optic nerve tension.
        </p>
      </div>
    </div>
  );
};
