import {
  Task,
  Note,
  Assignment,
  Exam,
  TimetableSlot,
  SubjectProgress,
  ResourceItem,
  CampusEvent,
  StudentClub,
  CommunityPost,
  Internship,
  BudgetItem,
  StudentProfile
} from '../types';

export const initialProfile: StudentProfile = {
  name: 'Alex Rivera',
  email: 'alex.rivera@university.edu',
  college: 'Institute of Science & Technology',
  degree: 'B.S. in Computer Science',
  semester: 'Semester 5 (Junior Year)',
  studentId: 'STU-2024-8849',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
  dailyStudyGoalHours: 4.5,
  notificationsEnabled: true,
  examRemindersEnabled: true
};

export const initialTasks: Task[] = [
  {
    id: 't-1',
    title: 'Complete Binary Search Tree Implementation',
    subject: 'Data Structures & Algorithms',
    dueDate: '2026-10-30',
    priority: 'high',
    completed: false,
    estimatedMinutes: 90
  },
  {
    id: 't-2',
    title: 'Solve Calculus Problem Set 4 (Green’s Theorem)',
    subject: 'Advanced Calculus',
    dueDate: '2026-10-29',
    priority: 'medium',
    completed: true,
    estimatedMinutes: 60
  },
  {
    id: 't-3',
    title: 'Review Chapter 5: Neural Networks & Backprop',
    subject: 'Intro to Machine Learning',
    dueDate: '2026-11-01',
    priority: 'high',
    completed: false,
    estimatedMinutes: 75
  },
  {
    id: 't-4',
    title: 'Prepare slides for Software Engineering sprint review',
    subject: 'Software Engineering',
    dueDate: '2026-11-02',
    priority: 'medium',
    completed: false,
    estimatedMinutes: 45
  },
  {
    id: 't-5',
    title: 'Read research paper on Database Sharding strategies',
    subject: 'Database Systems',
    dueDate: '2026-10-31',
    priority: 'low',
    completed: false,
    estimatedMinutes: 40
  },
  {
    id: 't-6',
    title: 'Submit Lab Experiment #6 on Operating System Threads',
    subject: 'Operating Systems',
    dueDate: '2026-10-28',
    priority: 'high',
    completed: true,
    estimatedMinutes: 60
  }
];

export const initialNotes: Note[] = [
  {
    id: 'n-1',
    title: 'Key Dynamic Programming Patterns',
    subject: 'Data Structures & Algorithms',
    content: `# Dynamic Programming Common Patterns\n\n1. **0/1 Knapsack**: Pick or skip items. Optimal substructure where weight <= W.\n2. **Longest Common Subsequence (LCS)**: Compare characters from back, recursion: \`dp[i][j] = dp[i-1][j-1] + 1\` if match.\n3. **Kadane's Algorithm**: Finding max subarray sum in O(n) time and O(1) space.\n\n> *Tip*: Always check constraints before selecting between Top-Down Memoization and Bottom-Up Tabulation.`,
    tags: ['Algorithms', 'LeetCode', 'InterviewPrep'],
    pinned: true,
    updatedAt: '2026-10-27T18:40:00Z',
    color: 'from-blue-500/10 to-indigo-500/10 border-blue-300 dark:border-blue-800'
  },
  {
    id: 'n-2',
    title: 'Gradient Descent & Learning Rate Formulas',
    subject: 'Intro to Machine Learning',
    content: `# Optimization & Backpropagation\n\n- **Weight Update Formula**: \n  \`w_new = w_old - (alpha * grad_loss)\`\n- **Momentum**: Accelerates SGD in relevant direction and dampens oscillations.\n- **Adam Optimizer**: Combines AdaGrad and RMSProp with exponentially decaying average of past squared gradients.`,
    tags: ['MachineLearning', 'Math', 'Formulas'],
    pinned: true,
    updatedAt: '2026-10-26T14:15:00Z',
    color: 'from-purple-500/10 to-pink-500/10 border-purple-300 dark:border-purple-800'
  },
  {
    id: 'n-3',
    title: 'ACID Properties & Isolation Levels',
    subject: 'Database Systems',
    content: `### ACID Guarantees\n\n- **Atomicity**: All or nothing transaction execution.\n- **Consistency**: Database transitions from one valid state to another.\n- **Isolation**: Concurrent transactions do not interfere.\n- **Durability**: Committed data survives system crashes.\n\n### Read Phenomena\n- Dirty Read\n- Non-repeatable Read\n- Phantom Read`,
    tags: ['Databases', 'SQL', 'SystemDesign'],
    pinned: false,
    updatedAt: '2026-10-24T11:00:00Z',
    color: 'from-emerald-500/10 to-teal-500/10 border-emerald-300 dark:border-emerald-800'
  },
  {
    id: 'n-4',
    title: 'Stokes Theorem & Vector Surface Integrals',
    subject: 'Advanced Calculus',
    content: `## Stokes' Theorem Summary\n\nRelates the surface integral of the curl of a vector field over an open surface S to the line integral of the vector field around boundary curve C.\n\n\`oint_C F . dr = iint_S (curl F) . dS\`\n\nRemember right-hand rule for the orientation of normal vector n!`,
    tags: ['Calculus', 'ExamNotes', 'Physics'],
    pinned: false,
    updatedAt: '2026-10-22T09:30:00Z',
    color: 'from-amber-500/10 to-orange-500/10 border-amber-300 dark:border-amber-800'
  }
];

export const initialAssignments: Assignment[] = [
  {
    id: 'a-1',
    title: 'Distributed Key-Value Store Implementation',
    subject: 'Distributed Systems',
    dueDate: '2026-11-04',
    status: 'in-progress',
    priority: 'high',
    description: 'Implement a Raft-based distributed key-value store in Go/Java with leader election and log replication support.',
    attachmentsCount: 3
  },
  {
    id: 'a-2',
    title: 'Convolutional Neural Network for CIFAR-10',
    subject: 'Intro to Machine Learning',
    dueDate: '2026-11-08',
    status: 'pending',
    priority: 'high',
    description: 'Train a CNN achieving > 85% validation accuracy. Include confusion matrix and ablation study in final PDF.',
    attachmentsCount: 1
  },
  {
    id: 'a-3',
    title: 'SQL Schema Optimization & Indexing Benchmark',
    subject: 'Database Systems',
    dueDate: '2026-10-27',
    status: 'submitted',
    priority: 'medium',
    grade: 'A (95%)',
    description: 'Analyze query execution plans using EXPLAIN ANALYZE on PostgreSQL with 5M rows.',
    attachmentsCount: 2
  },
  {
    id: 'a-4',
    title: 'Process Scheduling Simulation in C',
    subject: 'Operating Systems',
    dueDate: '2026-10-22',
    status: 'graded',
    priority: 'medium',
    grade: 'A+ (98%)',
    description: 'Simulate Round-Robin, Priority, and Shortest Job First CPU schedulers with metrics for turnaround time.',
    attachmentsCount: 4
  },
  {
    id: 'a-5',
    title: 'Vector Field Surface Integrals Problem Set',
    subject: 'Advanced Calculus',
    dueDate: '2026-11-01',
    status: 'in-progress',
    priority: 'medium',
    description: 'Solve questions 12 through 28 in Stewart Calculus Chapter 16.',
    attachmentsCount: 1
  }
];

export const initialExams: Exam[] = [
  {
    id: 'e-1',
    subject: 'Data Structures & Algorithms',
    title: 'Midterm Comprehensive Exam',
    date: '2026-11-12',
    time: '10:00 AM - 12:30 PM',
    room: 'Hall 402, Science Complex',
    weightage: '30% of Total Grade',
    topics: [
      { id: 'top-1', title: 'Asymptotic Analysis (Big-O, Omega, Theta)', completed: true },
      { id: 'top-2', title: 'Self-Balancing AVL and Red-Black Trees', completed: true },
      { id: 'top-3', title: 'Graph Traversal (BFS, DFS, Dijkstra, A*)', completed: false },
      { id: 'top-4', title: 'Dynamic Programming & Memoization', completed: false },
      { id: 'top-5', title: 'Disjoint-Set Union-Find & Kruskal’s MST', completed: false }
    ]
  },
  {
    id: 'e-2',
    subject: 'Machine Learning',
    title: 'Mid-Semester Theory & Practical Exam',
    date: '2026-11-18',
    time: '02:00 PM - 04:30 PM',
    room: 'Lab B, AI Wing',
    weightage: '25% of Total Grade',
    topics: [
      { id: 'top-21', title: 'Supervised vs Unsupervised Learning Paradigms', completed: true },
      { id: 'top-22', title: 'Linear Regression, Ridge and Lasso Regularization', completed: true },
      { id: 'top-23', title: 'Support Vector Machines & Kernel Trick', completed: false },
      { id: 'top-24', title: 'Multilayer Perceptrons & Backpropagation Math', completed: false }
    ]
  },
  {
    id: 'e-3',
    subject: 'Database Systems',
    title: 'Final Examination',
    date: '2026-12-05',
    time: '09:00 AM - 12:00 PM',
    room: 'Auditorium North',
    weightage: '40% of Total Grade',
    topics: [
      { id: 'top-31', title: 'Relational Algebra & Tuple Calculus', completed: true },
      { id: 'top-32', title: 'Normalization up to BCNF and 4NF', completed: true },
      { id: 'top-33', title: 'B+ Tree Indexing & Hash Indexes', completed: true },
      { id: 'top-34', title: 'Transaction Concurrency & Two-Phase Locking', completed: false }
    ]
  }
];

export const initialTimetable: TimetableSlot[] = [
  {
    id: 'tt-1',
    day: 'Monday',
    startTime: '09:00',
    endTime: '10:30',
    subject: 'Data Structures & Algorithms',
    room: 'Room 204',
    instructor: 'Dr. Evelyn Reed',
    color: 'bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-900/40 dark:text-blue-300 dark:border-blue-700'
  },
  {
    id: 'tt-2',
    day: 'Monday',
    startTime: '11:00',
    endTime: '12:30',
    subject: 'Advanced Calculus',
    room: 'Math Hall B',
    instructor: 'Prof. David Chen',
    color: 'bg-indigo-100 text-indigo-800 border-indigo-300 dark:bg-indigo-900/40 dark:text-indigo-300 dark:border-indigo-700'
  },
  {
    id: 'tt-3',
    day: 'Tuesday',
    startTime: '10:00',
    endTime: '12:00',
    subject: 'Intro to Machine Learning',
    room: 'Turing Lab',
    instructor: 'Dr. Samantha Wu',
    color: 'bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-900/40 dark:text-purple-300 dark:border-purple-700'
  },
  {
    id: 'tt-4',
    day: 'Tuesday',
    startTime: '14:00',
    endTime: '16:00',
    subject: 'Operating Systems Lab',
    room: 'Computing Lab 3',
    instructor: 'Prof. Alan Vance',
    color: 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-900/40 dark:text-emerald-300 dark:border-emerald-700'
  },
  {
    id: 'tt-5',
    day: 'Wednesday',
    startTime: '09:00',
    endTime: '10:30',
    subject: 'Data Structures & Algorithms',
    room: 'Room 204',
    instructor: 'Dr. Evelyn Reed',
    color: 'bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-900/40 dark:text-blue-300 dark:border-blue-700'
  },
  {
    id: 'tt-6',
    day: 'Wednesday',
    startTime: '13:00',
    endTime: '14:30',
    subject: 'Database Systems',
    room: 'Science 108',
    instructor: 'Dr. Marcus Brody',
    color: 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-900/40 dark:text-amber-300 dark:border-amber-700'
  },
  {
    id: 'tt-7',
    day: 'Thursday',
    startTime: '10:00',
    endTime: '12:00',
    subject: 'Intro to Machine Learning',
    room: 'Turing Lab',
    instructor: 'Dr. Samantha Wu',
    color: 'bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-900/40 dark:text-purple-300 dark:border-purple-700'
  },
  {
    id: 'tt-8',
    day: 'Friday',
    startTime: '09:00',
    endTime: '11:00',
    subject: 'Software Engineering Sprint',
    room: 'Project Center 1',
    instructor: 'Eng. Sarah Connor',
    color: 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-900/40 dark:text-rose-300 dark:border-rose-700'
  }
];

export const initialSubjectProgress: SubjectProgress[] = [
  {
    id: 'sub-1',
    name: 'Data Structures & Algorithms',
    code: 'CS 301',
    color: '#3b82f6',
    attendance: 94,
    syllabusCompleted: 78,
    targetGrade: 'A',
    hoursStudied: 42.5
  },
  {
    id: 'sub-2',
    name: 'Intro to Machine Learning',
    code: 'CS 345',
    color: '#8b5cf6',
    attendance: 88,
    syllabusCompleted: 65,
    targetGrade: 'A-',
    hoursStudied: 36.0
  },
  {
    id: 'sub-3',
    name: 'Database Systems',
    code: 'CS 320',
    color: '#10b981',
    attendance: 92,
    syllabusCompleted: 85,
    targetGrade: 'A',
    hoursStudied: 30.5
  },
  {
    id: 'sub-4',
    name: 'Advanced Calculus',
    code: 'MATH 240',
    color: '#f59e0b',
    attendance: 82,
    syllabusCompleted: 70,
    targetGrade: 'B+',
    hoursStudied: 28.0
  },
  {
    id: 'sub-5',
    name: 'Operating Systems',
    code: 'CS 310',
    color: '#ec4899',
    attendance: 96,
    syllabusCompleted: 82,
    targetGrade: 'A',
    hoursStudied: 34.0
  }
];

export const initialWeeklyStudyData = [
  { day: 'Mon', hours: 4.2, target: 4.5, pomodoros: 8 },
  { day: 'Tue', hours: 5.5, target: 4.5, pomodoros: 11 },
  { day: 'Wed', hours: 3.8, target: 4.5, pomodoros: 7 },
  { day: 'Thu', hours: 4.8, target: 4.5, pomodoros: 9 },
  { day: 'Fri', hours: 6.0, target: 4.5, pomodoros: 12 },
  { day: 'Sat', hours: 5.2, target: 4.5, pomodoros: 10 },
  { day: 'Sun', hours: 3.5, target: 4.5, pomodoros: 6 }
];

export const initialResources: ResourceItem[] = [
  {
    id: 'res-1',
    title: 'Visualgo - Visualising Data Structures & Algorithms',
    category: 'free-tool',
    subject: 'Computer Science',
    description: 'Interactive animated tool for understanding sorting, binary search trees, graph algorithms, and hash tables.',
    provider: 'National Univ of Singapore',
    link: 'https://visualgo.net',
    rating: 4.9,
    tags: ['Algorithms', 'Interactive', 'Free'],
    isBookmarked: true
  },
  {
    id: 'res-2',
    title: 'MIT OpenCourseWare: Introduction to Algorithms (6.006)',
    category: 'course',
    subject: 'Data Structures',
    description: 'Complete lecture videos, problem sets, and recitations by Prof. Erik Demaine and Srini Devadas.',
    provider: 'MIT OCW',
    link: 'https://ocw.mit.edu',
    rating: 5.0,
    tags: ['VideoLectures', 'MIT', 'Comprehensive'],
    isBookmarked: true
  },
  {
    id: 'res-3',
    title: 'Stanford Machine Learning Cheat Sheets',
    category: 'cheatsheet',
    subject: 'Machine Learning',
    description: 'Comprehensive 2-page cheatsheets by Afshine & Shervine Amidi covering Supervised, Unsupervised, and Deep Learning.',
    provider: 'Stanford University',
    link: 'https://stanford.edu/~shervine/teaching/cs-229/',
    rating: 4.8,
    tags: ['Cheatsheet', 'ML', 'QuickReview'],
    isBookmarked: false
  },
  {
    id: 'res-4',
    title: 'STEM Future Leaders Merit Scholarship 2026',
    category: 'scholarship',
    subject: 'Engineering & Sciences',
    description: '$10,000 annual grant awarded to undergraduate students demonstrating academic excellence and community impact.',
    provider: 'Global Tech Foundation',
    link: 'https://example.org/stem-scholarship',
    rating: 4.7,
    tags: ['FinancialAid', 'Undergraduate', 'Merit'],
    deadline: '2026-12-15',
    awardAmount: '$10,000 / Year',
    isBookmarked: true
  },
  {
    id: 'res-5',
    title: '3Blue1Brown: Essence of Linear Algebra',
    category: 'course',
    subject: 'Mathematics',
    description: 'Legendary visual animations explaining matrices, eigenvectors, determinants, and transformations intuitively.',
    provider: 'Grant Sanderson / 3B1B',
    link: 'https://www.youtube.com/@3blue1brown',
    rating: 5.0,
    tags: ['VisualMath', 'LinearAlgebra', 'YouTube'],
    isBookmarked: false
  },
  {
    id: 'res-6',
    title: 'Overleaf LaTeX Collaborative Document Editor',
    category: 'free-tool',
    subject: 'Academic Writing',
    description: 'Cloud-based LaTeX editor with hundreds of templates for IEEE papers, research thesis, and lab reports.',
    provider: 'Digital Science',
    link: 'https://www.overleaf.com',
    rating: 4.9,
    tags: ['LaTeX', 'Research', 'Templates'],
    isBookmarked: false
  },
  {
    id: 'res-7',
    title: 'Grace Hopper Student Scholar Grant',
    category: 'scholarship',
    subject: 'Diversity in Tech',
    description: 'Full travel and registration sponsorship for undergraduate computing students to attend the annual GHC conference.',
    provider: 'AnitaB.org',
    link: 'https://ghc.anitab.org',
    rating: 4.9,
    tags: ['Conference', 'TravelGrant', 'Diversity'],
    deadline: '2026-11-20',
    awardAmount: 'Full Sponsorship ($3,500)',
    isBookmarked: false
  }
];

export const initialEvents: CampusEvent[] = [
  {
    id: 'ev-1',
    title: 'HackCampus 2026: 36-Hour National Hackathon',
    category: 'workshop',
    date: '2026-11-07',
    time: '09:00 AM',
    location: 'Student Innovation Hub & Main Hall',
    organizer: 'Computer Science Society',
    description: 'Join 500+ student developers to build AI and sustainability solutions with mentorship from Google & Microsoft engineers.',
    attendeesCount: 342,
    isRegistered: true,
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'ev-2',
    title: 'Annual Tech Career Fair & On-Campus Interviews',
    category: 'career',
    date: '2026-11-14',
    time: '10:00 AM - 04:00 PM',
    location: 'University Gymnasium',
    organizer: 'Career Development Center',
    description: 'Meet recruiters from over 60 companies offering summer internships and graduate entry-level positions.',
    attendeesCount: 820,
    isRegistered: true,
    image: 'https://images.unsplash.com/photo-1515187029135-18ee286d815b?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'ev-3',
    title: 'Campus Beats: Autumn Music & Food Festival',
    category: 'cultural',
    date: '2026-11-20',
    time: '05:30 PM - 10:00 PM',
    location: 'East Quad Amphitheater',
    organizer: 'Student Affairs Board',
    description: 'Live student band performances, local artisan food trucks, dance battles, and light installations.',
    attendeesCount: 650,
    isRegistered: false,
    image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'ev-4',
    title: 'Inter-Collegiate Badminton & Table Tennis Tournament',
    category: 'sports',
    date: '2026-11-28',
    time: '08:30 AM',
    location: 'Sports Complex Arena',
    organizer: 'Athletics Department',
    description: 'Singles and doubles tournaments with cash prizes and university athletic trophies.',
    attendeesCount: 180,
    isRegistered: false,
    image: 'https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?auto=format&fit=crop&w=600&q=80'
  }
];

export const initialClubs: StudentClub[] = [
  {
    id: 'cl-1',
    name: 'Developer Student Club (DSC)',
    category: 'Technology',
    membersCount: 420,
    president: 'Maya Lin',
    meetingSchedule: 'Wednesdays @ 5:30 PM (CS Lab 102)',
    description: 'Hands-on workshops on React, Cloud Computing, Open Source, and collaborative team projects for social impact.',
    contactEmail: 'dsc@university.edu',
    isJoined: true,
    iconName: 'Code2'
  },
  {
    id: 'cl-2',
    name: 'AI & Robotics Research Guild',
    category: 'Academic',
    membersCount: 210,
    president: 'Liam Thorne',
    meetingSchedule: 'Fridays @ 4:00 PM (Robotics Wing)',
    description: 'Exploring neural architectures, autonomous drones, ROS2 robotics, and competitive Kaggle challenges.',
    contactEmail: 'robotics@university.edu',
    isJoined: true,
    iconName: 'Cpu'
  },
  {
    id: 'cl-3',
    name: 'Debate & Public Speaking Society',
    category: 'Leadership',
    membersCount: 145,
    president: 'Kavita Patel',
    meetingSchedule: 'Tuesdays @ 6:00 PM (Old Senate Room)',
    description: 'Parliamentary debates, Model UN simulations, and professional persuasive speaking training.',
    contactEmail: 'debate@university.edu',
    isJoined: false,
    iconName: 'Mic'
  },
  {
    id: 'cl-4',
    name: 'Outdoor Adventure & Trekking Club',
    category: 'Recreation',
    membersCount: 310,
    president: 'Julian Rossi',
    meetingSchedule: 'Alternate Weekends (Trailhead)',
    description: 'Weekend mountain hikes, camping retreats, bouldering sessions, and wilderness first-aid workshops.',
    contactEmail: 'outdoors@university.edu',
    isJoined: false,
    iconName: 'Compass'
  }
];

export const initialPosts: CommunityPost[] = [
  {
    id: 'post-1',
    authorName: 'Jordan Taylor',
    authorMajor: 'CS & Math, Senior',
    authorAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&q=80',
    title: 'How I balanced 18 credits while landing an Amazon SDE internship',
    content: 'My three golden rules: 1. Strict timeblocking with Google Calendar. 2. Active recall using Anki instead of passive re-reading. 3. Doing 2 LeetCode problems every single day during breakfast. Happy to review anyone’s resume this weekend!',
    tag: 'Career Advice',
    likes: 64,
    isLiked: true,
    commentsCount: 14,
    timestamp: '3 hours ago',
    replies: [
      {
        id: 'rep-1',
        authorName: 'Alex Rivera',
        content: 'Would love feedback on my resume for cloud backend roles! Will DM you on Discord.',
        timestamp: '2 hours ago'
      },
      {
        id: 'rep-2',
        authorName: 'Sarah Jenkins',
        content: 'The breakfast LeetCode routine is genius. Starting this tomorrow!',
        timestamp: '1 hour ago'
      }
    ]
  },
  {
    id: 'post-2',
    authorName: 'Elena Rostova',
    authorMajor: 'Data Science, Junior',
    authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80',
    title: 'Forming a study group for CS 345 Machine Learning Midterm!',
    content: 'Looking for 3-4 people to do practice problem walkthroughs in the library study room 3B on Monday & Thursday evenings. Focusing especially on backpropagation math and SVM proofs.',
    tag: 'Study Groups',
    likes: 31,
    isLiked: false,
    commentsCount: 8,
    timestamp: 'Yesterday',
    replies: [
      {
        id: 'rep-3',
        authorName: 'Marcus Cole',
        content: 'Count me in! I have the past 3 years of midterm solution keys.',
        timestamp: '18 hours ago'
      }
    ]
  },
  {
    id: 'post-3',
    authorName: 'Kevin Patel',
    authorMajor: 'Biomedical Eng, Sophomore',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    title: 'Best quiet study nooks on campus that people don’t know about',
    content: '3rd floor of the Architecture building has ergonomic armchairs, huge sunny windows, fast Wi-Fi, and near-zero foot traffic. Just please keep noise down!',
    tag: 'Campus Hacks',
    likes: 89,
    isLiked: true,
    commentsCount: 22,
    timestamp: '2 days ago'
  }
];

export const initialInternships: Internship[] = [
  {
    id: 'int-1',
    company: 'Stripe',
    role: 'Software Engineer Intern (Payments Core)',
    location: 'San Francisco, CA / Hybrid',
    type: 'Hybrid',
    stipend: '$58 / hour + Housing Allowance',
    deadline: '2026-11-25',
    requirements: ['Solid CS fundamentals in Java, Go, or Ruby', 'Understanding of distributed APIs', 'Curiosity for robust infrastructure'],
    description: 'Work alongside senior staff engineers scaling global transaction processing infrastructure handling billions in daily volume.',
    applyUrl: 'https://stripe.com/jobs',
    saved: true,
    tags: ['Backend', 'Fintech', 'Distributed Systems']
  },
  {
    id: 'int-2',
    company: 'Spotify',
    role: 'Product Design & UI/UX Intern',
    location: 'New York, NY / Remote',
    type: 'Remote',
    stipend: '$45 / hour',
    deadline: '2026-12-01',
    requirements: ['Strong Figma portfolio with user journey case studies', 'Interaction design experience', 'Passion for audio & creators'],
    description: 'Design innovative discovery features for Spotify mobile and desktop applications used by over 500 million active listeners.',
    applyUrl: 'https://spotify.com/careers',
    saved: true,
    tags: ['UI/UX', 'Design', 'Consumer Tech']
  },
  {
    id: 'int-3',
    company: 'DeepMind / Google AI',
    role: 'Research Student Intern (Applied ML)',
    location: 'Mountain View, CA',
    type: 'Full-time',
    stipend: '$62 / hour + Relocation',
    deadline: '2026-11-15',
    requirements: ['PyTorch or JAX proficiency', 'Probability and linear algebra mastery', 'Publications or strong open-source code'],
    description: 'Collaborate with world-class research scientists developing cutting-edge multimodal reasoning models and synthetic data pipelines.',
    applyUrl: 'https://google.com/students',
    saved: false,
    tags: ['AI/ML', 'Research', 'PyTorch']
  },
  {
    id: 'int-4',
    company: 'Microsoft',
    role: 'Cloud Solutions & DevOps Intern',
    location: 'Redmond, WA / Hybrid',
    type: 'Hybrid',
    stipend: '$52 / hour + Housing',
    deadline: '2026-12-10',
    requirements: ['Familiarity with Docker, Kubernetes or Azure', 'Scripting in Python or Bash', 'CI/CD pipeline understanding'],
    description: 'Help enterprise cloud customers build resilient high-availability microservices architecture on Microsoft Azure.',
    applyUrl: 'https://careers.microsoft.com',
    saved: false,
    tags: ['DevOps', 'Cloud', 'Azure']
  }
];

export const initialBudgetItems: BudgetItem[] = [
  { id: 'b-1', category: 'books', amount: 85, description: 'Calculus textbook & online portal license', date: '2026-10-10', type: 'expense' },
  { id: 'b-2', category: 'food', amount: 140, description: 'Weekly grocery store run & meal prep', date: '2026-10-18', type: 'expense' },
  { id: 'b-3', category: 'transport', amount: 45, description: 'Campus monthly subway / bus transit card', date: '2026-10-01', type: 'expense' },
  { id: 'b-4', category: 'entertainment', amount: 25, description: 'Campus cinema ticket & social cafe', date: '2026-10-22', type: 'expense' },
  { id: 'b-5', category: 'other', amount: 750, description: 'Campus TA Tutoring Stipend (Bi-weekly)', date: '2026-10-15', type: 'income' },
  { id: 'b-6', category: 'other', amount: 500, description: 'Academic Merit Scholarship Disbursement', date: '2026-10-01', type: 'income' },
  { id: 'b-7', category: 'food', amount: 35, description: 'Late night study pizza with team', date: '2026-10-25', type: 'expense' }
];

export const initialBlogs = [
  {
    id: 'blog-1',
    title: 'The Feynman Technique: How to Truly Understand Any Hard Concept',
    readTime: '4 min read',
    category: 'Productivity',
    author: 'Dr. Richard Vance',
    date: 'Oct 24, 2026',
    snippet: 'When you try to explain a complex topic in simple language to a 10-year old, you instantly uncover your true knowledge gaps.',
    tags: ['Learning', 'StudyTechniques', 'CognitiveScience']
  },
  {
    id: 'blog-2',
    title: 'Fighting Exam Anxiety: 5 Evidence-Backed Somatic Breathing Drills',
    readTime: '6 min read',
    category: 'Mental Wellness',
    author: 'Coach Maya Chen',
    date: 'Oct 21, 2026',
    snippet: 'Box breathing and the physiological sigh stimulate your vagus nerve to reduce resting heart rate within 90 seconds.',
    tags: ['Mindfulness', 'StressRelief', 'Health']
  },
  {
    id: 'blog-3',
    title: 'Student Budgeting 101: How to Save $200 Every Month Without Feeling Deprived',
    readTime: '5 min read',
    category: 'Finance',
    author: 'Samira Patel',
    date: 'Oct 19, 2026',
    snippet: 'Simple hacks including campus meal pooling, utilizing student software discounts, and automatic savings roundups.',
    tags: ['Money', 'Budgeting', 'CollegeLife']
  }
];
