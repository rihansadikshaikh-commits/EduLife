/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#f0f5ff',
          100: '#e0ecff',
          200: '#c7dcff',
          300: '#9ec4ff',
          400: '#6ea0ff',
          500: '#4378f7',
          600: '#2756eb',
          700: '#1e40d6',
          800: '#1d35ad',
          900: '#1c3187',
          950: '#141e52',
        },
        violet: {
          50: '#f6f5ff',
          100: '#eeebff',
          200: '#ded7ff',
          300: '#c5b5ff',
          400: '#a687ff',
          500: '#8758f6',
          600: '#7537ec',
          700: '#6426d4',
          800: '#531fae',
          900: '#451b8d',
          950: '#2b0e60',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      boxShadow: {
        'soft': '0 4px 20px -2px rgba(39, 86, 235, 0.08), 0 2px 6px -1px rgba(0, 0, 0, 0.04)',
        'soft-hover': '0 10px 30px -4px rgba(39, 86, 235, 0.16), 0 4px 10px -2px rgba(0, 0, 0, 0.05)',
        'glow': '0 0 25px -5px rgba(117, 55, 236, 0.35)',
      },
      animation: {
        'pulse-subtle': 'pulseSubtle 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'float': 'float 6s ease-in-out infinite',
      },
      keyframes: {
        pulseSubtle: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.85' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-8px)' },
        }
      }
    },
  },
  plugins: [],
}
