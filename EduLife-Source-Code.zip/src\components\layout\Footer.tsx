import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  GraduationCap,
  Heart,
  Send,
  Github,
  Twitter,
  Linkedin,
  Disc as Discord,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { useToast } from '../../context/ToastContext';

export const Footer: React.FC = () => {
  const { showToast } = useToast();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      showToast('Please enter a valid student email address.', 'error');
      return;
    }
    setSubscribed(true);
    showToast('Subscribed! Check your inbox for weekly student productivity digests.', 'success');
    setEmail('');
  };

  return (
    <footer className="border-t border-slate-200 dark:border-slate-800/80 bg-white dark:bg-slate-900/90 text-slate-600 dark:text-slate-400 transition-colors duration-200 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand & Newsletter Column */}
          <div className="lg:col-span-2 space-y-4">
            <Link to="/" className="flex items-center space-x-3 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 to-violet-600 flex items-center justify-center text-white shadow-md">
                <GraduationCap className="w-6 h-6" />
              </div>
              <span className="font-extrabold text-2xl tracking-tight bg-gradient-to-r from-brand-600 to-violet-600 bg-clip-text text-transparent">
                EduLife
              </span>
            </Link>
            <p className="text-sm leading-relaxed max-w-sm text-slate-500 dark:text-slate-400">
              The all-in-one student operating system. Manage your coursework, study sessions,
              assignments, campus life, and career opportunities in a single intuitive interface.
            </p>

            {/* Newsletter */}
            <div className="pt-2">
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-brand-500" />
                Join 24,000+ Students Newsletter
              </p>
              {subscribed ? (
                <div className="flex items-center space-x-2 text-sm text-emerald-600 dark:text-emerald-400 font-medium">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>You are subscribed to the weekly student digest!</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex max-w-sm gap-2">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your student email..."
                    className="flex-1 px-3.5 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-sm font-semibold transition-colors flex items-center justify-center shadow-sm"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Column 1: Study Tools */}
          <div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider mb-4">
              Study Tools
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/dashboard" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Student Dashboard
                </Link>
              </li>
              <li>
                <Link to="/planner" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Study Timetable & Planner
                </Link>
              </li>
              <li>
                <Link to="/notes" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Digital Smart Notes
                </Link>
              </li>
              <li>
                <Link to="/assignments" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Assignment Tracker
                </Link>
              </li>
              <li>
                <Link to="/exams" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Exam Countdown & Prep
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 2: Resources & Career */}
          <div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider mb-4">
              Growth & Career
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/resources" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Free Study Materials
                </Link>
              </li>
              <li>
                <Link to="/resources" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Scholarships Directory
                </Link>
              </li>
              <li>
                <Link to="/career" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Internships & Co-ops
                </Link>
              </li>
              <li>
                <Link to="/career" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Resume Builder Tips
                </Link>
              </li>
              <li>
                <Link to="/career" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Interview Question Bank
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Student Life */}
          <div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider mb-4">
              Student Life
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/community" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Campus Events
                </Link>
              </li>
              <li>
                <Link to="/community" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Clubs & Student Societies
                </Link>
              </li>
              <li>
                <Link to="/community" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Student Discussion Forum
                </Link>
              </li>
              <li>
                <Link to="/settings" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Budget Calculator
                </Link>
              </li>
              <li>
                <Link to="/planner" className="hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                  Wellness & Pomodoro
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-10 mt-10 border-t border-slate-100 dark:border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center space-x-2 text-slate-500">
            <span>© {new Date().getFullYear()} EduLife Platform. Designed with</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 inline" />
            <span>for students worldwide.</span>
          </div>

          {/* Operational Status */}
          <div className="flex items-center space-x-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-medium border border-emerald-500/20">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>All Systems Live & Synchronized</span>
          </div>

          {/* Socials */}
          <div className="flex items-center space-x-4 text-slate-400">
            <a
              href="https://github.com"
              target="_blank"
              rel="noreferrer"
              className="hover:text-brand-600 dark:hover:text-white transition-colors"
              aria-label="GitHub"
            >
              <Github className="w-4 h-4" />
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noreferrer"
              className="hover:text-brand-600 dark:hover:text-white transition-colors"
              aria-label="Twitter"
            >
              <Twitter className="w-4 h-4" />
            </a>
            <a
              href="https://discord.com"
              target="_blank"
              rel="noreferrer"
              className="hover:text-brand-600 dark:hover:text-white transition-colors"
              aria-label="Discord"
            >
              <Discord className="w-4 h-4" />
            </a>
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noreferrer"
              className="hover:text-brand-600 dark:hover:text-white transition-colors"
              aria-label="LinkedIn"
            >
              <Linkedin className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
