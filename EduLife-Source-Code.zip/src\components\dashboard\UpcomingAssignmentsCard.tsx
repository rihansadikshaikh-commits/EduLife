import React from 'react';
import { Link } from 'react-router-dom';
import { CheckSquare, ArrowRight, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useAppData } from '../../context/AppDataContext';
import { useToast } from '../../context/ToastContext';

export const UpcomingAssignmentsCard: React.FC = () => {
  const { assignments, updateAssignmentStatus } = useAppData();
  const { showToast } = useToast();

  const pendingAssignments = assignments
    .filter((a) => a.status === 'pending' || a.status === 'in-progress')
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate))
    .slice(0, 3);

  const handleQuickSubmit = (id: string, title: string) => {
    updateAssignmentStatus(id, 'submitted');
    showToast(`Marked "${title}" as submitted! Great job!`, 'success');
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400">
              <CheckSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Upcoming Deadlines
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {pendingAssignments.length} assignments due soon
              </p>
            </div>
          </div>
          <Link
            to="/assignments"
            className="text-xs font-semibold text-brand-600 dark:text-brand-400 hover:text-brand-500 flex items-center space-x-1"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {pendingAssignments.length === 0 ? (
          <div className="text-center py-8 text-slate-400">
            <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-500 mb-2 opacity-80" />
            <p className="text-xs font-medium">All assignments submitted! You’re caught up.</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {pendingAssignments.map((assignment) => {
              const isUrgent = assignment.priority === 'high';
              return (
                <div
                  key={assignment.id}
                  className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex items-center justify-between hover:bg-slate-100/70 dark:hover:bg-slate-800 transition-colors"
                >
                  <div className="flex-1 pr-3">
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-purple-100 dark:bg-purple-900/50 text-purple-700 dark:text-purple-300">
                        {assignment.subject}
                      </span>
                      {isUrgent && (
                        <span className="flex items-center space-x-0.5 text-[10px] font-semibold text-rose-600 dark:text-rose-400">
                          <AlertCircle className="w-3 h-3" />
                          <span>Urgent</span>
                        </span>
                      )}
                    </div>
                    <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 mt-1 line-clamp-1">
                      {assignment.title}
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Due: {assignment.dueDate}
                    </p>
                  </div>

                  <button
                    onClick={() => handleQuickSubmit(assignment.id, assignment.title)}
                    className="px-2.5 py-1.5 text-[11px] font-semibold rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-brand-600 hover:text-white dark:hover:bg-brand-600 transition-colors shrink-0"
                    title="Mark as Submitted"
                  >
                    Submit
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
        <span>Average GPA: 3.82</span>
        <span className="text-brand-600 dark:text-brand-400 font-medium">Semester Honors</span>
      </div>
    </div>
  );
};
