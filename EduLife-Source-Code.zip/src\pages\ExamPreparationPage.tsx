import React, { useState } from 'react';
import {
  Clock,
  Plus,
  CheckCircle2,
  Circle,
  Calendar,
  MapPin,
  Award,
  Lightbulb,
  Trash2,
  BrainCircuit,
  BookOpen,
  Sparkles
} from 'lucide-react';
import { useAppData } from '../context/AppDataContext';
import { useToast } from '../context/ToastContext';
import { Modal } from '../components/common/Modal';
import { Exam } from '../types';

const REVISION_STRATEGIES = [
  {
    title: 'Active Recall vs. Passive Reading',
    description:
      'Testing yourself with flashcards or practice questions forces neural retrieval pathways, resulting in 50% higher retention compared to re-reading highlights.',
    tag: 'Cognitive Science'
  },
  {
    title: 'Spaced Repetition Schedule (1-3-7-14)',
    description:
      'Review a difficult topic 1 day after learning, then 3 days later, then at day 7, and finally at day 14 to flatten the Ebbinghaus forgetting curve completely.',
    tag: 'Memory Protocol'
  },
  {
    title: 'The Blurting Revision Method',
    description:
      'Read a textbook subsection, close the book, and write down everything you remember on a blank sheet for 5 minutes. Compare and highlight what you missed.',
    tag: 'Quick Diagnostic'
  },
  {
    title: 'Sleep Consolidates Procedural Memory',
    description:
      'All-nighters before quantitative exams diminish cognitive processing by up to 35%. Prioritize 7-8 hours of sleep for deep REM memory synthesis.',
    tag: 'Wellness & Stamina'
  }
];

export const ExamPreparationPage: React.FC = () => {
  const { exams, addExam, deleteExam, toggleExamTopic } = useAppData();
  const { showToast } = useToast();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [subject, setSubject] = useState('');
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('10:00 AM - 12:30 PM');
  const [room, setRoom] = useState('');
  const [weightage, setWeightage] = useState('30% of Total Grade');
  const [topicsInput, setTopicsInput] = useState('');

  const handleAddExam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !title.trim() || !date) {
      showToast('Please fill in required fields', 'error');
      return;
    }

    const topics = topicsInput
      .split('\n')
      .map((t) => t.trim())
      .filter((t) => t.length > 0)
      .map((t, idx) => ({
        id: `top-${Date.now()}-${idx}`,
        title: t,
        completed: false
      }));

    addExam({
      subject,
      title,
      date,
      time,
      room: room || 'Hall TBD',
      weightage,
      topics: topics.length > 0 ? topics : [{ id: `top-${Date.now()}`, title: 'General Syllabus Review', completed: false }]
    });

    showToast(`Exam scheduled for ${subject}!`, 'success');
    setIsAddModalOpen(false);
    setSubject('');
    setTitle('');
    setDate('');
    setTopicsInput('');
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2.5">
            <Clock className="w-8 h-8 text-brand-600" />
            Exam Preparation & Syllabus Tracker
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Master your midterm and final exams with real-time countdowns, topic checklists, and memory strategies.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center space-x-2 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-brand-600 to-violet-600 hover:from-brand-500 hover:to-violet-500 text-white font-semibold text-sm shadow-md shadow-brand-500/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Exam</span>
        </button>
      </div>

      {/* Exam Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {exams.map((exam) => {
          const examDate = new Date(exam.date);
          const today = new Date();
          const diffDays = Math.max(0, Math.ceil((examDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
          const completedCount = exam.topics.filter((t) => t.completed).length;
          const totalCount = exam.topics.length;
          const percent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

          return (
            <div
              key={exam.id}
              className="p-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm flex flex-col justify-between space-y-4"
            >
              <div>
                {/* Header & Days Left Pill */}
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-brand-600 dark:text-brand-400">
                      {exam.subject}
                    </span>
                    <h3 className="font-bold text-base text-slate-900 dark:text-slate-100 mt-0.5">
                      {exam.title}
                    </h3>
                  </div>

                  <div className="flex flex-col items-end">
                    <span
                      className={`text-xs font-black px-3 py-1 rounded-xl flex items-center gap-1 ${
                        diffDays <= 7
                          ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-300'
                          : 'bg-brand-50 text-brand-700 dark:bg-brand-950/60 dark:text-brand-300 border border-brand-200'
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      {diffDays === 0 ? 'Today!' : `${diffDays} Days Left`}
                    </span>
                  </div>
                </div>

                {/* Exam logistics */}
                <div className="mt-3 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs space-y-1.5 text-slate-600 dark:text-slate-400">
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>
                      {exam.date} • {exam.time}
                    </span>
                  </div>
                  {exam.room && (
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>{exam.room}</span>
                    </div>
                  )}
                  {exam.weightage && (
                    <div className="flex items-center space-x-2">
                      <Award className="w-3.5 h-3.5 text-brand-500" />
                      <span>Weightage: {exam.weightage}</span>
                    </div>
                  )}
                </div>

                {/* Syllabus progress bar */}
                <div className="mt-4 space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-slate-700 dark:text-slate-300">Syllabus Covered</span>
                    <span className="text-brand-600 dark:text-brand-400">
                      {completedCount}/{totalCount} topics ({percent}%)
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-brand-500 to-emerald-500 transition-all duration-500 rounded-full"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>

                {/* Topics checklist */}
                <div className="mt-4 space-y-2">
                  <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Topic Breakdown
                  </p>
                  <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                    {exam.topics.map((topic) => (
                      <div
                        key={topic.id}
                        onClick={() => toggleExamTopic(exam.id, topic.id)}
                        className={`p-2 rounded-xl text-xs flex items-center space-x-2.5 cursor-pointer transition-colors border ${
                          topic.completed
                            ? 'bg-emerald-50/50 dark:bg-emerald-950/20 text-slate-400 line-through border-emerald-200/50 dark:border-emerald-800/30'
                            : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200/80 dark:border-slate-700 hover:border-brand-400'
                        }`}
                      >
                        {topic.completed ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                        ) : (
                          <Circle className="w-4 h-4 text-slate-400 shrink-0" />
                        )}
                        <span className="truncate">{topic.title}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card footer */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-400">
                <span>{percent === 100 ? '✅ 100% Prepared' : 'In Revision'}</span>
                <button
                  onClick={() => {
                    deleteExam(exam.id);
                    showToast('Exam removed', 'info');
                  }}
                  className="p-1 hover:text-rose-600 transition-colors"
                  title="Remove Exam"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Exam Revision Techniques & Tips */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-2xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400">
            <BrainCircuit className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">
              Evidence-Based Exam Preparation Protocols
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Scientifically proven learning strategies used by top academic performers.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {REVISION_STRATEGIES.map((strat) => (
            <div
              key={strat.title}
              className="p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 space-y-2 hover:border-amber-300 dark:hover:border-amber-700 transition-all"
            >
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-sm text-slate-900 dark:text-slate-100">
                  {strat.title}
                </h4>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300">
                  {strat.tag}
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                {strat.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Add Exam Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Schedule New Exam"
      >
        <form onSubmit={handleAddExam} className="space-y-4 text-left">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Subject *
              </label>
              <input
                type="text"
                required
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Distributed Systems"
                className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Exam Title *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Midterm Comprehensive"
                className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Date *
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Time Window
              </label>
              <input
                type="text"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                placeholder="e.g. 10:00 AM - 12:30 PM"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Exam Hall / Room
              </label>
              <input
                type="text"
                value={room}
                onChange={(e) => setRoom(e.target.value)}
                placeholder="e.g. Science Complex 402"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Grade Weightage
              </label>
              <input
                type="text"
                value={weightage}
                onChange={(e) => setWeightage(e.target.value)}
                placeholder="e.g. 35% of Total Grade"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Syllabus Topics (one per line)
            </label>
            <textarea
              rows={4}
              value={topicsInput}
              onChange={(e) => setTopicsInput(e.target.value)}
              placeholder="Linear Regression & Loss functions&#10;Backpropagation Math&#10;Support Vector Machines"
              className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-brand-600 hover:bg-brand-500 rounded-xl shadow-sm"
            >
              Schedule Exam
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
