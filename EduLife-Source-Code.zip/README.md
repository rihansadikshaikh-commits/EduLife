# 🎓 EduLife – Education & Student Life Platform

> **"Your Student Life, Simplified."**  
> Learn smarter, stay organized, and make the most of your student journey.

EduLife is a modern, responsive, and visually attractive student platform built with **React**, **Vite**, **TypeScript**, **Tailwind CSS**, and **Recharts**.

---

## 🌟 Key Features

1. **Interactive Student Dashboard**
   - Today's study schedule and class timings
   - Upcoming assignment deadlines with urgent indicators
   - Dynamic exam countdown timer
   - Daily study goals with progress tracking
   - Weekly study hours chart (Recharts)
   - Subject-wise progress & syllabus completion

2. **Smart Study Tools**
   - **Pomodoro Focus Timer**: Deep focus intervals, breaks, and audio alert
   - **Interactive Timetable**: Weekly schedule planner with color coding
   - **Notes Taking**: Rich markdown notes with tags, subjects, and search
   - **Assignment Tracker**: Kanban board and table views with deadline alerts
   - **Exam Preparation Tracker**: Syllabus checklists and memory revision strategies
   - **Mental Wellness Widget**: Guided 4-4-4 box breathing exercise

3. **Education Resources & Career**
   - Curated cheat sheets and free academic tools
   - Scholarships & grants directory
   - Internship job board with type filters (Remote, Hybrid, Full-time)
   - ATS-friendly resume audit checklist
   - High-frequency interview question bank
   - Student budget & monthly expense planner

4. **Campus Community & Life**
   - College events with interactive RSVP
   - Student clubs directory
   - Discussion forum with replies and likes
   - Student wellness and productivity blogs

5. **Design & Settings**
   - Beautiful blue and violet modern theme
   - Full Light / Dark mode support
   - Daily study goal customizer
   - LocalStorage persistence with JSON backup export & reset

---

## 🚀 Tech Stack

- **Frontend**: React 18, Vite, TypeScript
- **Styling**: Tailwind CSS, PostCSS, Lucide React Icons
- **Data & Charts**: Recharts, Canvas Confetti
- **Storage**: Browser LocalStorage

---

## 💻 Getting Started

### Prerequisites
- Node.js (v18 or higher recommended)
- npm or pnpm

### Installation
```bash
# Clone the repository
git clone <your-repo-url>
cd edulife-platform

# Install dependencies
npm install

# Start the development server
npm run dev
```

Visit `http://localhost:5173` in your browser.

### Build for Production
```bash
npm run build
npm run preview
```

---

## 📄 License
MIT License. Created for students worldwide!
