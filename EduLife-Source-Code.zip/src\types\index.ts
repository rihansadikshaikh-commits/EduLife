export type Priority = 'low' | 'medium' | 'high';

export interface Task {
  id: string;
  title: string;
  subject: string;
  dueDate: string;
  priority: Priority;
  completed: boolean;
  estimatedMinutes?: number;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  subject: string;
  tags: string[];
  pinned: boolean;
  updatedAt: string;
  color?: string;
}

export type AssignmentStatus = 'pending' | 'in-progress' | 'submitted' | 'graded';

export interface Assignment {
  id: string;
  title: string;
  subject: string;
  dueDate: string;
  status: AssignmentStatus;
  priority: Priority;
  grade?: string;
  description: string;
  attachmentsCount?: number;
}

export interface Exam {
  id: string;
  subject: string;
  title: string;
  date: string; // ISO string or YYYY-MM-DD
  time: string;
  room?: string;
  weightage?: string;
  topics: {
    id: string;
    title: string;
    completed: boolean;
  }[];
}

export interface TimetableSlot {
  id: string;
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday';
  startTime: string; // "09:00"
  endTime: string;   // "10:30"
  subject: string;
  room: string;
  instructor: string;
  color: string;
}

export interface SubjectProgress {
  id: string;
  name: string;
  code: string;
  color: string;
  attendance: number; // percentage e.g. 88
  syllabusCompleted: number; // percentage e.g. 75
  targetGrade: string;
  hoursStudied: number;
}

export interface ResourceItem {
  id: string;
  title: string;
  category: 'notes' | 'free-tool' | 'cheatsheet' | 'course' | 'scholarship';
  subject: string;
  description: string;
  provider: string;
  link: string;
  rating: number;
  tags: string[];
  isBookmarked?: boolean;
  deadline?: string; // for scholarships
  awardAmount?: string; // for scholarships
}

export interface CampusEvent {
  id: string;
  title: string;
  category: 'academic' | 'cultural' | 'sports' | 'workshop' | 'career';
  date: string;
  time: string;
  location: string;
  organizer: string;
  description: string;
  attendeesCount: number;
  isRegistered?: boolean;
  image?: string;
}

export interface StudentClub {
  id: string;
  name: string;
  category: string;
  membersCount: number;
  president: string;
  meetingSchedule: string;
  description: string;
  contactEmail: string;
  isJoined?: boolean;
  iconName: string;
}

export interface CommunityPost {
  id: string;
  authorName: string;
  authorMajor: string;
  authorAvatar: string;
  title: string;
  content: string;
  tag: string;
  likes: number;
  isLiked?: boolean;
  commentsCount: number;
  timestamp: string;
  replies?: {
    id: string;
    authorName: string;
    content: string;
    timestamp: string;
  }[];
}

export interface Internship {
  id: string;
  company: string;
  role: string;
  location: string;
  type: 'Full-time' | 'Part-time' | 'Remote' | 'Hybrid';
  stipend: string;
  deadline: string;
  requirements: string[];
  description: string;
  applyUrl: string;
  saved?: boolean;
  tags: string[];
}

export interface BudgetItem {
  id: string;
  category: 'food' | 'rent' | 'books' | 'transport' | 'entertainment' | 'other';
  amount: number;
  description: string;
  date: string;
  type: 'expense' | 'income';
}

export interface StudentProfile {
  name: string;
  email: string;
  college: string;
  degree: string;
  semester: string;
  studentId: string;
  avatarUrl: string;
  dailyStudyGoalHours: number;
  notificationsEnabled: boolean;
  examRemindersEnabled: boolean;
}
