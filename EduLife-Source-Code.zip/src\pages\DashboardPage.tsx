import React from 'react';
import { Link } from 'react-router-dom';
import {
  Calendar,
  Flame,
  Award,
  BookOpen,
  ArrowRight,
  GraduationCap
} from 'lucide-react';
import { useAppData } from '../context/AppDataContext';
import { TodayScheduleCard } from '../components/dashboard/TodayScheduleCard';
import { UpcomingAssignmentsCard } from '../components/dashboard/UpcomingAssignmentsCard';
import { ExamCountdownCard } from '../components/dashboard/ExamCountdownCard';
import { DailyGoalsCard } from '../components/dashboard/DailyGoalsCard';
import { WeeklyStudyChart } from '../components/dashboard/WeeklyStudyChart';
import { QuickAccessCards } from '../components/dashboard/QuickAccessCards';

export const DashboardPage: React.FC = () => {
  const { profile, subjectProgress } = useAppData();

  const formattedDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Welcome Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
        <div className="flex items-center space-x-4">
          <img
            src={profile.avatarUrl}
            alt={profile.name}
            className="w-16 h-16 rounded-2xl object-cover ring-4 ring-brand-500/20 shadow-md"
          />
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-brand-50 dark:bg-brand-950/60 text-brand-600 dark:text-brand-300 border border-brand-200 dark:border-brand-800">
                {profile.degree}
              </span>
              <span className="text-xs text-slate-400">•</span>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {profile.semester}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              Welcome back, {profile.name}! 👋
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
              Today is {formattedDate}. You have 3 tasks and 1 lecture on your agenda.
            </p>
          </div>
        </div>

        {/* Quick stats pills */}
        <div className="flex items-center space-x-2 sm:space-x-3 self-start md:self-auto">
          <div className="px-4 py-2.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 flex items-center space-x-2">
            <Flame className="w-5 h-5 text-amber-500 animate-pulse" />
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 leading-none">
                Streak
              </p>
              <p className="text-sm font-extrabold leading-tight">14 Days</p>
            </div>
          </div>

          <div className="px-4 py-2.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 flex items-center space-x-2">
            <Award className="w-5 h-5 text-emerald-500" />
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 leading-none">
                GPA Goal
              </p>
              <p className="text-sm font-extrabold leading-tight">3.90 (Current 3.82)</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Access Tools Bar */}
      <QuickAccessCards />

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top Priority Cards */}
        <ExamCountdownCard />
        <UpcomingAssignmentsCard />
        <TodayScheduleCard />
      </div>

      {/* Analytics & Tasks Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <WeeklyStudyChart />
        </div>
        <div>
          <DailyGoalsCard />
        </div>
      </div>

      {/* Subject-Wise Progress Section */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-brand-500" />
              Subject-Wise Progress & Syllabus Completion
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Track your revision status, attendance records, and target semester grades.
            </p>
          </div>
          <Link
            to="/planner"
            className="text-xs font-semibold text-brand-600 dark:text-brand-400 hover:text-brand-500 flex items-center space-x-1"
          >
            <span>Study Planner</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {subjectProgress.map((subj) => (
            <div
              key={subj.id}
              className="p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3"
            >
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400">
                    {subj.code}
                  </span>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate max-w-[180px]">
                    {subj.name}
                  </h4>
                </div>
                <span className="text-xs font-extrabold px-2 py-0.5 rounded-lg bg-brand-50 dark:bg-brand-950/60 text-brand-600 dark:text-brand-300 border border-brand-200 dark:border-brand-800">
                  Target: {subj.targetGrade}
                </span>
              </div>

              {/* Progress Bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px] text-slate-500 dark:text-slate-400">
                  <span>Syllabus Covered</span>
                  <strong className="text-slate-700 dark:text-slate-300">{subj.syllabusCompleted}%</strong>
                </div>
                <div className="w-full h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${subj.syllabusCompleted}%`,
                      backgroundColor: subj.color
                    }}
                  />
                </div>
              </div>

              {/* Attendance and study hours */}
              <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                <span>
                  Attendance: <strong className="text-emerald-600 dark:text-emerald-400">{subj.attendance}%</strong>
                </span>
                <span>
                  Hours: <strong className="text-slate-700 dark:text-slate-300">{subj.hoursStudied}h</strong>
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
