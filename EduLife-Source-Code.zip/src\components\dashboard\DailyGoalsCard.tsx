import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, Circle, Plus, ListTodo, ArrowRight } from 'lucide-react';
import { useAppData } from '../../context/AppDataContext';
import { useToast } from '../../context/ToastContext';

export const DailyGoalsCard: React.FC = () => {
  const { tasks, toggleTask, addTask } = useAppData();
  const { showToast } = useToast();

  const [quickTitle, setQuickTitle] = useState('');

  const completedCount = tasks.filter((t) => t.completed).length;
  const totalCount = tasks.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const handleQuickAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickTitle.trim()) return;

    addTask({
      title: quickTitle,
      subject: 'General Study',
      dueDate: new Date().toISOString().split('T')[0],
      priority: 'medium',
      completed: false,
      estimatedMinutes: 30
    });

    showToast(`Added: "${quickTitle}"`, 'success');
    setQuickTitle('');
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
              <ListTodo className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Daily Study Goals
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {completedCount} of {totalCount} completed ({progressPercent}%)
              </p>
            </div>
          </div>
          <Link
            to="/planner"
            className="text-xs font-semibold text-brand-600 dark:text-brand-400 hover:text-brand-500 flex items-center space-x-1"
          >
            <span>Planner</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {/* Progress bar */}
        <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden mb-4">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-500 rounded-full"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Tasks list */}
        <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
          {tasks.slice(0, 4).map((task) => (
            <div
              key={task.id}
              onClick={() => toggleTask(task.id)}
              className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                task.completed
                  ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/40 text-slate-400 line-through'
                  : 'bg-slate-50 dark:bg-slate-800/40 border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center space-x-2.5 truncate pr-2">
                {task.completed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                ) : (
                  <Circle className="w-4 h-4 text-slate-400 shrink-0" />
                )}
                <span className="text-xs font-medium truncate">{task.title}</span>
              </div>
              <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-white dark:bg-slate-700 text-slate-500 shrink-0">
                {task.priority}
              </span>
            </div>
          ))}
        </div>

        {/* Quick add input */}
        <form onSubmit={handleQuickAdd} className="mt-3 flex gap-2">
          <input
            type="text"
            value={quickTitle}
            onChange={(e) => setQuickTitle(e.target.value)}
            placeholder="Add quick goal..."
            className="flex-1 px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-brand-500"
          />
          <button
            type="submit"
            className="px-3 py-1.5 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1 shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add</span>
          </button>
        </form>
      </div>

      <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
        <span>Daily Consistency Streak: 🔥 14 Days</span>
        <span className="text-brand-600 dark:text-brand-400 font-semibold">Keep it going!</span>
      </div>
    </div>
  );
};
