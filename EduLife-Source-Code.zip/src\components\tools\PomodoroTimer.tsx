import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Flame, Coffee, Sparkles, CheckCircle2 } from 'lucide-react';
import { useAppData } from '../../context/AppDataContext';
import { useToast } from '../../context/ToastContext';
import confetti from 'canvas-confetti';

type TimerMode = 'work' | 'shortBreak' | 'longBreak';

const TIMER_MODES: Record<TimerMode, { label: string; defaultMinutes: number; color: string }> = {
  work: { label: 'Deep Focus', defaultMinutes: 25, color: 'from-brand-600 to-indigo-600' },
  shortBreak: { label: 'Short Break', defaultMinutes: 5, color: 'from-emerald-600 to-teal-600' },
  longBreak: { label: 'Long Break', defaultMinutes: 15, color: 'from-purple-600 to-pink-600' }
};

export const PomodoroTimer: React.FC = () => {
  const { recordStudySession } = useAppData();
  const { showToast } = useToast();

  const [mode, setMode] = useState<TimerMode>('work');
  const [timeLeft, setTimeLeft] = useState(TIMER_MODES.work.defaultMinutes * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [completedSessions, setCompletedSessions] = useState(0);

  const initialTime = TIMER_MODES[mode].defaultMinutes * 60;
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Play audio chime using Web Audio API
  const playSoundAlert = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.3); // A5
      gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.8);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.8);
    } catch {
      // AudioContext might be blocked before first user interaction
    }
  };

  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            setIsRunning(false);
            playSoundAlert();

            if (mode === 'work') {
              setCompletedSessions((c) => c + 1);
              recordStudySession(TIMER_MODES.work.defaultMinutes);
              showToast('🎉 Focus session completed! 25 minutes added to study stats.', 'success');
              try {
                confetti({ particleCount: 60, spread: 60 });
              } catch {
                // ignore
              }
              setMode('shortBreak');
              return TIMER_MODES.shortBreak.defaultMinutes * 60;
            } else {
              showToast('Break is over! Time to focus again.', 'info');
              setMode('work');
              return TIMER_MODES.work.defaultMinutes * 60;
            }
          }
          return prev - 1;
        });
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, mode, recordStudySession, showToast]);

  const switchMode = (newMode: TimerMode) => {
    setIsRunning(false);
    setMode(newMode);
    setTimeLeft(TIMER_MODES[newMode].defaultMinutes * 60);
  };

  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(TIMER_MODES[mode].defaultMinutes * 60);
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  const progressPercent = ((initialTime - timeLeft) / initialTime) * 100;

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm relative overflow-hidden">
      {/* Background soft glow */}
      <div className="absolute -top-12 -right-12 w-40 h-40 bg-brand-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Mode Switches */}
      <div className="flex items-center justify-center p-1 bg-slate-100 dark:bg-slate-800/80 rounded-2xl mb-6 max-w-sm mx-auto">
        <button
          onClick={() => switchMode('work')}
          className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
            mode === 'work'
              ? 'bg-white dark:bg-slate-700 text-brand-600 dark:text-brand-300 shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Flame className="w-3.5 h-3.5" />
          Focus (25m)
        </button>
        <button
          onClick={() => switchMode('shortBreak')}
          className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
            mode === 'shortBreak'
              ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-300 shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Coffee className="w-3.5 h-3.5" />
          Short (5m)
        </button>
        <button
          onClick={() => switchMode('longBreak')}
          className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
            mode === 'longBreak'
              ? 'bg-white dark:bg-slate-700 text-purple-600 dark:text-purple-300 shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          Long (15m)
        </button>
      </div>

      {/* Timer Display */}
      <div className="flex flex-col items-center justify-center py-4">
        <div className="relative flex items-center justify-center">
          {/* Circular progress visual indicator */}
          <div className="text-6xl sm:text-7xl font-extrabold tracking-tight tabular-nums text-slate-900 dark:text-white font-mono my-2">
            {formattedTime}
          </div>
        </div>

        {/* Linear progress bar */}
        <div className="w-full max-w-xs h-2 bg-slate-100 dark:bg-slate-800 rounded-full mt-2 mb-6 overflow-hidden">
          <div
            className={`h-full bg-gradient-to-r ${TIMER_MODES[mode].color} transition-all duration-300`}
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Controls */}
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white font-semibold shadow-md transition-all transform hover:scale-105 active:scale-95 bg-gradient-to-r ${TIMER_MODES[mode].color}`}
            aria-label={isRunning ? 'Pause Timer' : 'Start Timer'}
          >
            {isRunning ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-0.5" />}
          </button>
          <button
            onClick={resetTimer}
            className="w-12 h-12 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-center text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/80 transition-all"
            aria-label="Reset Timer"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
        </div>

        {/* Stats footer */}
        <div className="mt-6 flex items-center space-x-6 text-xs text-slate-500 dark:text-slate-400">
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            Completed Today: <strong className="text-slate-800 dark:text-slate-200">{completedSessions}</strong>
          </span>
          <span>•</span>
          <span>Target: <strong>8 Pomodoros</strong></span>
        </div>
      </div>
    </div>
  );
};
