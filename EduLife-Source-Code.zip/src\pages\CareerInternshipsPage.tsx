import React, { useState } from 'react';
import {
  Briefcase,
  Search,
  Bookmark,
  BookmarkCheck,
  ExternalLink,
  DollarSign,
  MapPin,
  Clock,
  CheckCircle2,
  FileCheck,
  HelpCircle,
  PiggyBank,
  Plus,
  Trash2,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { useAppData } from '../context/AppDataContext';
import { useToast } from '../context/ToastContext';
import { Modal } from '../components/common/Modal';
import { BudgetItem } from '../types';

const RESUME_CHECKLIST = [
  { id: 'rc-1', text: 'Quantified impact metrics (e.g. "improved latency by 32%", "processed 10k requests")' },
  { id: 'rc-2', text: 'Clear technical skills section broken into Languages, Frameworks, and Cloud/Tools' },
  { id: 'rc-3', text: 'Live project links to deployed GitHub repos or hosted demos' },
  { id: 'rc-4', text: '1-page limit with clean ATS-friendly standard fonts and margins' },
  { id: 'rc-5', text: 'Action verbs starting every bullet (e.g. Architected, Optimized, Engineered)' }
];

const INTERVIEW_QUESTIONS = [
  {
    id: 'iq-1',
    category: 'Behavioral',
    question: 'Tell me about a time you had a technical disagreement with a teammate.',
    framework: 'STAR (Situation, Task, Action, Result)',
    tips: 'Focus on how you evaluated trade-offs collaboratively with objective data or benchmarks rather than ego.'
  },
  {
    id: 'iq-2',
    category: 'Technical Core',
    question: 'Explain the difference between Process and Thread, and how OS context switches work.',
    framework: 'Memory Space & Scheduling',
    tips: 'Mention shared heap vs private stack, CPU registers reload, and PCB/TCB data structures.'
  },
  {
    id: 'iq-3',
    category: 'System Design',
    question: 'How would you design a scalable URL shortener like bit.ly?',
    framework: 'API Design + Hashing + DB Sharding',
    tips: 'Discuss Base62 encoding, read-heavy 100:1 caching with Redis, and unique ID generation (Snowflake).'
  }
];

export const CareerInternshipsPage: React.FC = () => {
  const { internships, toggleSaveInternship, budget, addBudgetItem, deleteBudgetItem } = useAppData();
  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<'internships' | 'resume' | 'interview' | 'budget'>('internships');
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [savedOnly, setSavedOnly] = useState(false);

  // Resume check state
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({ 'rc-1': true, 'rc-2': true });

  // Interview questions accordion
  const [expandedQuestion, setExpandedQuestion] = useState<string | null>('iq-1');

  // Budget Modal State
  const [isBudgetModalOpen, setIsBudgetModalOpen] = useState(false);
  const [bCategory, setBCategory] = useState<BudgetItem['category']>('food');
  const [bAmount, setBAmount] = useState(25);
  const [bDescription, setBDescription] = useState('');
  const [bType, setBType] = useState<'expense' | 'income'>('expense');

  const toggleResumeCheck = (id: string) => {
    setCheckedItems((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleAddBudget = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bDescription.trim() || bAmount <= 0) {
      showToast('Please enter valid amount and description', 'error');
      return;
    }

    addBudgetItem({
      category: bCategory,
      amount: Number(bAmount),
      description: bDescription,
      date: new Date().toISOString().split('T')[0],
      type: bType
    });

    showToast(`Recorded ${bType === 'income' ? 'income' : 'expense'} of $${bAmount}`, 'success');
    setIsBudgetModalOpen(false);
    setBDescription('');
    setBAmount(25);
  };

  // Calculations for Student Budget
  const totalIncome = budget
    .filter((b) => b.type === 'income')
    .reduce((acc, curr) => acc + curr.amount, 0);
  const totalExpenses = budget
    .filter((b) => b.type === 'expense')
    .reduce((acc, curr) => acc + curr.amount, 0);
  const netBalance = totalIncome - totalExpenses;

  const filteredInternships = internships.filter((item) => {
    const matchesSearch =
      item.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.tags.some((t) => t.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesType = typeFilter === 'all' || item.type === typeFilter;
    const matchesSaved = !savedOnly || item.saved;
    return matchesSearch && matchesType && matchesSaved;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2.5">
            <Briefcase className="w-8 h-8 text-brand-600" />
            Career, Internships & Student Finances
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Browse verified student internships, review ATS resume standards, and balance your monthly budget.
          </p>
        </div>

        {/* Tab switchers */}
        <div className="flex items-center space-x-1 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 self-start sm:self-auto">
          {(['internships', 'resume', 'interview', 'budget'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all ${
                activeTab === tab
                  ? 'bg-white dark:bg-slate-700 text-brand-600 dark:text-brand-300 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {tab === 'internships'
                ? 'Internship Board'
                : tab === 'resume'
                ? 'Resume Checklist'
                : tab === 'interview'
                ? 'Interview Prep'
                : 'Student Budget'}
            </button>
          ))}
        </div>
      </div>

      {/* Tab 1: Internships Board */}
      {activeTab === 'internships' && (
        <div className="space-y-6">
          {/* Filter Bar */}
          <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by company, role (e.g. SDE, Design, Cloud)..."
                className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>

            <div className="flex items-center space-x-2">
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 outline-none"
              >
                <option value="all">All Work Types</option>
                <option value="Remote">Remote</option>
                <option value="Hybrid">Hybrid</option>
                <option value="Full-time">Full-time Onsite</option>
              </select>

              <button
                onClick={() => setSavedOnly(!savedOnly)}
                className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-all ${
                  savedOnly
                    ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border-rose-300'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
                }`}
              >
                {savedOnly ? <BookmarkCheck className="w-4 h-4 text-rose-500" /> : <Bookmark className="w-4 h-4" />}
                <span>Saved ({internships.filter((i) => i.saved).length})</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredInternships.map((item) => (
              <div
                key={item.id}
                className="p-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm flex flex-col justify-between space-y-4 hover:shadow-lg transition-all group"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-xs font-extrabold text-brand-600 dark:text-brand-400">
                        {item.company}
                      </span>
                      <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mt-0.5">
                        {item.role}
                      </h3>
                    </div>

                    <button
                      onClick={() => {
                        toggleSaveInternship(item.id);
                        showToast(
                          item.saved ? 'Removed from saved roles' : 'Saved internship to your tracker!',
                          item.saved ? 'info' : 'success'
                        );
                      }}
                      className={`p-1.5 rounded-xl transition-colors ${
                        item.saved
                          ? 'text-rose-500 bg-rose-50 dark:bg-rose-950/50'
                          : 'text-slate-400 hover:text-slate-600'
                      }`}
                      title="Save Job"
                    >
                      {item.saved ? <BookmarkCheck className="w-4 h-4 fill-current" /> : <Bookmark className="w-4 h-4" />}
                    </button>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-3 leading-relaxed">
                    {item.description}
                  </p>

                  <div className="mt-3.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs space-y-1 text-slate-600 dark:text-slate-400">
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>{item.location} ({item.type})</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <DollarSign className="w-3.5 h-3.5 text-emerald-500" />
                      <strong className="text-emerald-600 dark:text-emerald-400">{item.stipend}</strong>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="w-3.5 h-3.5 text-amber-500" />
                      <span>Deadline: {item.deadline}</span>
                    </div>
                  </div>

                  {/* Requirements Pills */}
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {item.tags.map((t) => (
                      <span
                        key={t}
                        className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">Direct Application Portal</span>
                  <a
                    href={item.applyUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-brand-600 hover:bg-brand-500 shadow-sm transition-all"
                  >
                    <span>Apply Now</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Resume Checklist */}
      {activeTab === 'resume' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-2xl bg-brand-50 dark:bg-brand-950/60 text-brand-600 dark:text-brand-400">
              <FileCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">
                ATS-Optimized Resume Audit Checklist
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Tick each standard to ensure your student resume passes recruiter parsing algorithms.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {RESUME_CHECKLIST.map((item) => (
              <div
                key={item.id}
                onClick={() => toggleResumeCheck(item.id)}
                className={`p-4 rounded-2xl border flex items-center space-x-3 cursor-pointer transition-all ${
                  checkedItems[item.id]
                    ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800 text-slate-800 dark:text-slate-200'
                    : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-colors ${
                    checkedItems[item.id]
                      ? 'bg-emerald-500 border-emerald-500 text-white'
                      : 'border-slate-300 dark:border-slate-600'
                  }`}
                >
                  {checkedItems[item.id] && <CheckCircle2 className="w-4 h-4" />}
                </div>
                <span className="text-xs font-semibold leading-relaxed">{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Interview Question Bank */}
      {activeTab === 'interview' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-2xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400">
              <HelpCircle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">
                High-Frequency Interview Question Bank
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Real interview scenarios asked by tech, consulting, and finance recruiters.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {INTERVIEW_QUESTIONS.map((q) => {
              const isExpanded = expandedQuestion === q.id;
              return (
                <div
                  key={q.id}
                  className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-slate-50/60 dark:bg-slate-800/40"
                >
                  <div
                    onClick={() => setExpandedQuestion(isExpanded ? null : q.id)}
                    className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-100/60 dark:hover:bg-slate-800 transition-colors"
                  >
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
                        {q.category}
                      </span>
                      <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                        {q.question}
                      </h4>
                    </div>
                    {isExpanded ? <ChevronUp className="w-5 h-5 text-slate-400" /> : <ChevronDown className="w-5 h-5 text-slate-400" />}
                  </div>

                  {isExpanded && (
                    <div className="p-4 pt-2 border-t border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs space-y-2">
                      <p>
                        <strong className="text-slate-700 dark:text-slate-300">Answer Framework:</strong>{' '}
                        <span className="text-brand-600 dark:text-brand-400 font-semibold">{q.framework}</span>
                      </p>
                      <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                        <strong className="text-slate-700 dark:text-slate-300">Strategy & Tips:</strong> {q.tips}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 4: Student Budget Planner */}
      {activeTab === 'budget' && (
        <div className="space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
              <span className="text-xs text-slate-500 font-medium">Monthly Inflow / Stipends</span>
              <h3 className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
                +${totalIncome.toFixed(2)}
              </h3>
            </div>
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
              <span className="text-xs text-slate-500 font-medium">Monthly Outflow / Expenses</span>
              <h3 className="text-2xl font-black text-rose-500 mt-1">
                -${totalExpenses.toFixed(2)}
              </h3>
            </div>
            <div className="p-5 rounded-3xl bg-gradient-to-r from-brand-600 to-violet-600 text-white shadow-lg shadow-brand-500/20">
              <span className="text-xs text-blue-100 font-medium">Remaining Student Balance</span>
              <h3 className="text-2xl font-black mt-1">
                ${netBalance.toFixed(2)}
              </h3>
            </div>
          </div>

          {/* Budget Items Table */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <PiggyBank className="w-5 h-5 text-brand-500" />
                  Student Allowance & Expense Log
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Track meal budgets, textbook costs, and student job stipends.
                </p>
              </div>

              <button
                onClick={() => setIsBudgetModalOpen(true)}
                className="flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-brand-600 hover:bg-brand-500 shadow-sm transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>Add Entry</span>
              </button>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {budget.map((item) => (
                <div key={item.id} className="py-3 flex items-center justify-between text-xs">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-slate-900 dark:text-slate-100">
                        {item.description}
                      </span>
                      <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500">
                        {item.category}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 mt-0.5 block">{item.date}</span>
                  </div>

                  <div className="flex items-center space-x-3">
                    <span
                      className={`font-black text-sm ${
                        item.type === 'income' ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-500'
                      }`}
                    >
                      {item.type === 'income' ? '+' : '-'}${item.amount.toFixed(2)}
                    </span>
                    <button
                      onClick={() => {
                        deleteBudgetItem(item.id);
                        showToast('Budget entry deleted', 'info');
                      }}
                      className="p-1 text-slate-400 hover:text-rose-600"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Add Budget Entry Modal */}
      <Modal
        isOpen={isBudgetModalOpen}
        onClose={() => setIsBudgetModalOpen(false)}
        title="Add Expense or Income Entry"
      >
        <form onSubmit={handleAddBudget} className="space-y-4 text-left">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Type
              </label>
              <select
                value={bType}
                onChange={(e) => setBType(e.target.value as 'expense' | 'income')}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              >
                <option value="expense">Expense (Outflow)</option>
                <option value="income">Income (Inflow / Grant / TA)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Amount ($)
              </label>
              <input
                type="number"
                min="1"
                step="0.01"
                required
                value={bAmount}
                onChange={(e) => setBAmount(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Description *
            </label>
            <input
              type="text"
              required
              value={bDescription}
              onChange={(e) => setBDescription(e.target.value)}
              placeholder="e.g. Lab manual, Campus bus pass, Grocery run"
              className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Category
            </label>
            <select
              value={bCategory}
              onChange={(e) => setBCategory(e.target.value as BudgetItem['category'])}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
            >
              <option value="food">Food & Groceries</option>
              <option value="books">Books & Academic Supplies</option>
              <option value="rent">Rent & Dorm Living</option>
              <option value="transport">Transit & Commute</option>
              <option value="entertainment">Social & Coffee</option>
              <option value="other">Other / Miscellaneous</option>
            </select>
          </div>

          <div className="flex justify-end space-x-2 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsBudgetModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-brand-600 hover:bg-brand-500 rounded-xl shadow-sm"
            >
              Save Entry
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
