import React from 'react';
import { Link } from 'react-router-dom';
import {
  GraduationCap,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Calendar,
  Clock,
  BookOpen,
  Users,
  Briefcase,
  TrendingUp,
  ShieldCheck,
  Star,
  Quote
} from 'lucide-react';
import { useAppData } from '../context/AppDataContext';

const FEATURES = [
  {
    icon: Calendar,
    title: 'Smart Timetable & Planner',
    description: 'Keep lectures, labs, and study sessions organized with conflict detection and room location hints.',
    gradient: 'from-blue-500 to-indigo-600',
    link: '/planner'
  },
  {
    icon: Clock,
    title: 'Focus Pomodoro & Timer',
    description: 'Crush procrastination with scientifically proven deep focus intervals, gentle chimes, and automatic study logging.',
    gradient: 'from-purple-500 to-pink-600',
    link: '/planner'
  },
  {
    icon: CheckCircle2,
    title: 'Assignment & Deadline Hub',
    description: 'Track course submissions with visual urgency meters, Kanban boards, and milestone celebrations.',
    gradient: 'from-emerald-500 to-teal-600',
    link: '/assignments'
  },
  {
    icon: BookOpen,
    title: 'Curated Study Materials',
    description: 'Access top-rated MIT & Stanford cheatsheets, free academic developer tools, and verified scholarship listings.',
    gradient: 'from-amber-500 to-orange-600',
    link: '/resources'
  },
  {
    icon: Users,
    title: 'Campus Life & Community',
    description: 'Discover hackathons, join student clubs, and collaborate with peers across engineering, business, and arts.',
    gradient: 'from-cyan-500 to-blue-600',
    link: '/community'
  },
  {
    icon: Briefcase,
    title: 'Internships & Career Prep',
    description: 'Browse verified student internships at top companies, master interview questions, and polish your resume.',
    gradient: 'from-rose-500 to-red-600',
    link: '/career'
  }
];

const STATS = [
  { value: '24,000+', label: 'Active Students' },
  { value: '98.4%', label: 'On-Time Submission Rate' },
  { value: '3.82', label: 'Average Platform GPA' },
  { value: '150+', label: 'Campus Clubs & Groups' }
];

const TESTIMONIALS = [
  {
    quote:
      'EduLife replaced three separate apps for me. Having my exam countdown, assignments, and Pomodoro timer on one dashboard changed my semester from chaotic to straight A’s.',
    name: 'Sophia Martinez',
    role: 'Computer Science Junior',
    university: 'Institute of Technology',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
    rating: 5
  },
  {
    quote:
      'The scholarship directory alone helped me secure a $5,000 STEM merit grant! Plus the community forum is where I found my current hackathon team.',
    name: 'Marcus Vance',
    role: 'Data Science & Economics Senior',
    university: 'State University',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
    rating: 5
  },
  {
    quote:
      'The subject syllabus checklists make exam revision actually manageable. You can physically see your progress tick up day by day.',
    name: 'Emily Chen',
    role: 'Biomedical Engineering Sophomore',
    university: 'City College of Science',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&q=80',
    rating: 5
  }
];

export const HomePage: React.FC = () => {
  const { profile } = useAppData();

  return (
    <div className="space-y-24">
      {/* Hero Section */}
      <section className="relative pt-6 sm:pt-12 pb-16 text-center overflow-hidden">
        {/* Ambient Gradient Background Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] sm:w-[800px] h-[400px] bg-gradient-to-tr from-brand-500/20 via-violet-500/20 to-pink-500/10 blur-[120px] rounded-full -z-10 pointer-events-none" />

        <div className="max-w-4xl mx-auto space-y-6">
          {/* Pill Badge */}
          <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-brand-50 dark:bg-brand-950/70 border border-brand-200 dark:border-brand-800 text-brand-700 dark:text-brand-300 text-xs font-semibold shadow-sm animate-pulse-subtle">
            <Sparkles className="w-4 h-4 text-brand-600 dark:text-brand-400" />
            <span>The Complete Platform for Student Excellence</span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.1]">
            Your Student Life,{' '}
            <span className="bg-gradient-to-r from-brand-600 via-indigo-600 to-violet-600 dark:from-brand-400 dark:via-indigo-300 dark:to-violet-400 bg-clip-text text-transparent">
              Simplified.
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-xl text-slate-600 dark:text-slate-300 max-w-2xl mx-auto font-normal leading-relaxed">
            Learn smarter, stay organized, and make the most of your student journey. Manage
            coursework, deadlines, campus clubs, and career milestones all in one place.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Link
              to="/dashboard"
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-brand-600 to-violet-600 hover:from-brand-500 hover:to-violet-500 text-white font-semibold text-base shadow-lg shadow-brand-500/25 hover:shadow-brand-500/40 transform hover:-translate-y-0.5 transition-all flex items-center justify-center space-x-2 group"
            >
              <span>Get Started Free</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
            <a
              href="#features"
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-800 dark:text-slate-200 font-semibold text-base shadow-sm transition-all flex items-center justify-center space-x-2"
            >
              <span>Explore Features</span>
            </a>
          </div>

          {/* Trust points */}
          <div className="pt-6 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-500 dark:text-slate-400">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              100% Free for Students
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              Runs Locally & Saves Progress
            </span>
            <span className="flex items-center gap-1.5">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
              4.9/5 Student Rating
            </span>
          </div>
        </div>

        {/* Dashboard Preview Mockup Card */}
        <div className="mt-14 max-w-5xl mx-auto rounded-3xl border border-slate-200/80 dark:border-slate-800 bg-white/70 dark:bg-slate-900/70 p-3 sm:p-5 shadow-2xl backdrop-blur-xl">
          <div className="rounded-2xl border border-slate-200/50 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 sm:p-6 text-left">
            {/* Mock Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200/60 dark:border-slate-800 gap-3">
              <div className="flex items-center space-x-3">
                <img
                  src={profile.avatarUrl}
                  alt={profile.name}
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-brand-500"
                />
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    Welcome back, {profile.name} 👋
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {profile.degree} • {profile.semester}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                  ● 3 Active Deep Work Sessions Today
                </span>
              </div>
            </div>

            {/* Quick Interactive Peek Row */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
              <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800 shadow-sm">
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">Next Lecture</p>
                <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mt-1">
                  Data Structures & Algorithms
                </h4>
                <p className="text-xs text-brand-600 dark:text-brand-400 mt-1 flex items-center gap-1 font-medium">
                  <Clock className="w-3.5 h-3.5" /> Room 204 • Starts in 45m
                </p>
              </div>

              <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800 shadow-sm">
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">Upcoming Due Date</p>
                <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mt-1">
                  Distributed Raft Store
                </h4>
                <p className="text-xs text-rose-500 mt-1 flex items-center gap-1 font-medium">
                  <Clock className="w-3.5 h-3.5" /> Due in 3 days • High Priority
                </p>
              </div>

              <div className="p-4 rounded-xl bg-gradient-to-r from-brand-600 to-violet-600 text-white shadow-sm flex items-center justify-between">
                <div>
                  <p className="text-xs text-blue-100 font-semibold">Weekly Goal</p>
                  <h4 className="text-lg font-extrabold mt-0.5">32.7 / 35 hrs</h4>
                  <p className="text-[11px] text-blue-200">93% Target Reached</p>
                </div>
                <Link
                  to="/dashboard"
                  className="px-3 py-1.5 bg-white text-brand-700 text-xs font-bold rounded-xl shadow-sm hover:bg-blue-50 transition-colors"
                >
                  Open Dashboard
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="border-y border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/50 py-12 rounded-3xl">
        <div className="max-w-6xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {STATS.map((stat) => (
            <div key={stat.label} className="space-y-1">
              <div className="text-3xl sm:text-4xl font-black bg-gradient-to-r from-brand-600 to-violet-600 bg-clip-text text-transparent">
                {stat.value}
              </div>
              <p className="text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-400">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Features Grid Section */}
      <section id="features" className="space-y-12">
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-600 dark:text-brand-400">
            Engineered for Student Productivity
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
            Everything You Need To Thrive This Academic Year
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400">
            Stop switching between chaotic spreadsheets, disjointed to-do apps, and forgotten calendar invites.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEATURES.map((feat) => {
            const Icon = feat.icon;
            return (
              <Link
                key={feat.title}
                to={feat.link}
                className="p-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-brand-300 dark:hover:border-brand-700 hover:shadow-xl transition-all group flex flex-col justify-between"
              >
                <div>
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white mb-5 shadow-md bg-gradient-to-tr ${feat.gradient} group-hover:scale-110 transition-transform`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
                    {feat.title}
                  </h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">
                    {feat.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center text-xs font-semibold text-brand-600 dark:text-brand-400 group-hover:translate-x-1 transition-transform space-x-1">
                  <span>Open Tool</span>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="space-y-12">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-600 dark:text-brand-400">
            Student Stories
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
            Loved By Ambitious Students Worldwide
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.name}
              className="p-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center space-x-1 text-amber-400 mb-4">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400" />
                  ))}
                </div>
                <Quote className="w-8 h-8 text-brand-500/20 mb-2" />
                <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed italic">
                  "{t.quote}"
                </p>
              </div>

              <div className="flex items-center space-x-3 mt-6 pt-4 border-t border-slate-100 dark:border-slate-800">
                <img
                  src={t.avatar}
                  alt={t.name}
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-brand-500/30"
                />
                <div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">{t.name}</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">{t.role}</p>
                  <p className="text-[10px] text-brand-600 dark:text-brand-400">{t.university}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Call to Action Banner */}
      <section className="rounded-3xl bg-gradient-to-r from-brand-600 via-indigo-600 to-violet-700 p-8 sm:p-14 text-white shadow-xl shadow-brand-500/20 text-center relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-white/10 rounded-full blur-3xl pointer-events-none" />
        <div className="max-w-3xl mx-auto space-y-6 relative z-10">
          <GraduationCap className="w-12 h-12 mx-auto text-white/90" />
          <h2 className="text-3xl sm:text-5xl font-black tracking-tight">
            Ready to Take Control of Your Student Journey?
          </h2>
          <p className="text-base sm:text-lg text-blue-100 max-w-xl mx-auto">
            Join thousands of university students organizing coursework, exams, and career prep with EduLife today.
          </p>
          <div className="pt-2">
            <Link
              to="/dashboard"
              className="inline-flex items-center space-x-2 px-8 py-4 rounded-2xl bg-white text-brand-700 hover:bg-blue-50 font-bold text-base shadow-lg transition-transform hover:scale-105"
            >
              <span>Launch Your Dashboard Now</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};
