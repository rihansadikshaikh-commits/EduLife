import React, { useState } from 'react';
import {
  Users,
  Calendar,
  MessageSquare,
  Heart,
  Plus,
  MapPin,
  Clock,
  Send,
  Sparkles,
  BookOpen,
  CheckCircle2,
  Share2
} from 'lucide-react';
import { useAppData } from '../context/AppDataContext';
import { useToast } from '../context/ToastContext';
import { Modal } from '../components/common/Modal';
import { initialBlogs } from '../data/initialData';
import { CampusEvent } from '../types';

export const StudentCommunityPage: React.FC = () => {
  const {
    events,
    toggleRegisterEvent,
    clubs,
    toggleJoinClub,
    posts,
    addPost,
    toggleLikePost,
    addCommentToPost,
    profile
  } = useAppData();
  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<'events' | 'clubs' | 'forum' | 'blogs'>('events');
  const [eventFilter, setEventFilter] = useState<string>('all');

  // New Post Modal
  const [isPostModalOpen, setIsPostModalOpen] = useState(false);
  const [postTitle, setPostTitle] = useState('');
  const [postContent, setPostContent] = useState('');
  const [postTag, setPostTag] = useState('Study Groups');

  // Comment input per post
  const [activeCommentPostId, setActiveCommentPostId] = useState<string | null>(null);
  const [commentText, setCommentText] = useState('');

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!postTitle.trim() || !postContent.trim()) {
      showToast('Please enter both title and content', 'error');
      return;
    }

    addPost({
      authorName: profile.name,
      authorMajor: `${profile.degree}, ${profile.semester.split(' ')[0]}`,
      authorAvatar: profile.avatarUrl,
      title: postTitle,
      content: postContent,
      tag: postTag
    });

    showToast('Post published to student forum!', 'success');
    setIsPostModalOpen(false);
    setPostTitle('');
    setPostContent('');
  };

  const handleAddComment = (postId: string) => {
    if (!commentText.trim()) return;
    addCommentToPost(postId, commentText);
    showToast('Reply added to discussion!', 'success');
    setCommentText('');
    setActiveCommentPostId(null);
  };

  const filteredEvents = events.filter(
    (e) => eventFilter === 'all' || e.category === eventFilter
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2.5">
            <Users className="w-8 h-8 text-brand-600" />
            Student Community & Campus Life
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Connect with campus clubs, attend tech hackathons, ask questions, and share study advice.
          </p>
        </div>

        {/* Tab switchers */}
        <div className="flex items-center space-x-1 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 self-start sm:self-auto">
          {(['events', 'clubs', 'forum', 'blogs'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all ${
                activeTab === tab
                  ? 'bg-white dark:bg-slate-700 text-brand-600 dark:text-brand-300 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {tab === 'events'
                ? 'Campus Events'
                : tab === 'clubs'
                ? 'Student Clubs'
                : tab === 'forum'
                ? 'Discussion Forum'
                : 'Student Blogs'}
            </button>
          ))}
        </div>
      </div>

      {/* Tab 1: Campus Events */}
      {activeTab === 'events' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">
                Upcoming Campus Events & Activities
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                RSVP for hackathons, career fairs, cultural festivals, and sports tournaments.
              </p>
            </div>

            {/* Category filter */}
            <div className="flex items-center space-x-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs">
              {(['all', 'workshop', 'career', 'cultural', 'sports'] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setEventFilter(f)}
                  className={`px-2.5 py-1 rounded-lg capitalize transition-colors ${
                    eventFilter === f
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm font-semibold'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredEvents.map((event) => (
              <div
                key={event.id}
                className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm hover:shadow-lg transition-all flex flex-col justify-between"
              >
                {event.image && (
                  <div className="h-44 w-full relative overflow-hidden">
                    <img
                      src={event.image}
                      alt={event.title}
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                    />
                    <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-900/80 backdrop-blur-md text-white border border-white/20">
                      {event.category}
                    </div>
                  </div>
                )}

                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                      {event.title}
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">
                      {event.description}
                    </p>

                    <div className="mt-4 space-y-1.5 text-xs text-slate-500 dark:text-slate-400">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-3.5 h-3.5 text-brand-500" />
                        <span>
                          {event.date} • {event.time}
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <MapPin className="w-3.5 h-3.5 text-rose-500" />
                        <span>{event.location}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-[11px] text-slate-400">
                        <span>Organized by: {event.organizer}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                      👥 {event.attendeesCount} Students Attending
                    </span>

                    <button
                      onClick={() => {
                        toggleRegisterEvent(event.id);
                        showToast(
                          event.isRegistered ? 'RSVP Cancelled' : '🎉 Successfully RSVP’d to event!',
                          event.isRegistered ? 'info' : 'success'
                        );
                      }}
                      className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                        event.isRegistered
                          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300'
                          : 'bg-brand-600 hover:bg-brand-500 text-white shadow-sm'
                      }`}
                    >
                      {event.isRegistered ? '✓ Registered' : 'RSVP Free'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Student Clubs */}
      {activeTab === 'clubs' && (
        <div className="space-y-6">
          <div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">
              Student Organizations & Guilds
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Join active campus communities, make lifelong friends, and lead student projects.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {clubs.map((club) => (
              <div
                key={club.id}
                className="p-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm flex flex-col justify-between space-y-4 hover:border-brand-300 dark:hover:border-brand-700 transition-all"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300">
                        {club.category}
                      </span>
                      <h4 className="text-base font-bold text-slate-900 dark:text-slate-100 mt-1">
                        {club.name}
                      </h4>
                    </div>

                    <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                      👥 {club.membersCount} Members
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-3 leading-relaxed">
                    {club.description}
                  </p>

                  <div className="mt-4 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs space-y-1 text-slate-600 dark:text-slate-400">
                    <p>
                      <strong>Meetings:</strong> {club.meetingSchedule}
                    </p>
                    <p>
                      <strong>President:</strong> {club.president}
                    </p>
                    <p>
                      <strong>Contact:</strong> {club.contactEmail}
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-400 font-medium">Campus Verified Club</span>
                  <button
                    onClick={() => {
                      toggleJoinClub(club.id);
                      showToast(
                        club.isJoined ? 'Left club roster' : '🎉 You joined the club!',
                        club.isJoined ? 'info' : 'success'
                      );
                    }}
                    className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                      club.isJoined
                        ? 'bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-300'
                        : 'bg-brand-600 hover:bg-brand-500 text-white shadow-sm'
                    }`}
                  >
                    {club.isJoined ? '✓ Joined Club' : 'Join Club'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Discussion Forum */}
      {activeTab === 'forum' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">
                Student Discussion Board & Advice
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Ask questions, share interview tips, form study groups, and connect.
              </p>
            </div>

            <button
              onClick={() => setIsPostModalOpen(true)}
              className="flex items-center space-x-1.5 px-4 py-2 rounded-2xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-semibold shadow-sm transition-all self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Create Post</span>
            </button>
          </div>

          <div className="space-y-4">
            {posts.map((post) => (
              <div
                key={post.id}
                className="p-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm space-y-4"
              >
                {/* Author row */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <img
                      src={post.authorAvatar}
                      alt={post.authorName}
                      className="w-10 h-10 rounded-full object-cover ring-2 ring-brand-500/20"
                    />
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                        {post.authorName}
                      </h4>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        {post.authorMajor} • {post.timestamp}
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                    #{post.tag}
                  </span>
                </div>

                <div>
                  <h3 className="font-bold text-base text-slate-900 dark:text-slate-100">
                    {post.title}
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 leading-relaxed whitespace-pre-wrap">
                    {post.content}
                  </p>
                </div>

                {/* Interactions Bar */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center space-x-6 text-xs text-slate-500 dark:text-slate-400">
                  <button
                    onClick={() => toggleLikePost(post.id)}
                    className={`flex items-center space-x-1.5 font-semibold transition-colors ${
                      post.isLiked ? 'text-rose-500' : 'hover:text-rose-500'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${post.isLiked ? 'fill-rose-500' : ''}`} />
                    <span>{post.likes} Likes</span>
                  </button>

                  <button
                    onClick={() =>
                      setActiveCommentPostId(activeCommentPostId === post.id ? null : post.id)
                    }
                    className="flex items-center space-x-1.5 font-semibold hover:text-brand-600 transition-colors"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>{post.commentsCount} Replies</span>
                  </button>
                </div>

                {/* Replies Thread */}
                {post.replies && post.replies.length > 0 && (
                  <div className="pl-4 sm:pl-8 border-l-2 border-slate-100 dark:border-slate-800 space-y-2.5 pt-2">
                    {post.replies.map((reply) => (
                      <div
                        key={reply.id}
                        className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 text-xs"
                      >
                        <div className="flex items-center justify-between text-[11px] mb-1">
                          <strong className="text-slate-800 dark:text-slate-200">
                            {reply.authorName}
                          </strong>
                          <span className="text-slate-400">{reply.timestamp}</span>
                        </div>
                        <p className="text-slate-600 dark:text-slate-400">{reply.content}</p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Inline Comment Form */}
                {activeCommentPostId === post.id && (
                  <div className="flex items-center space-x-2 pt-2">
                    <input
                      type="text"
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      placeholder="Write a constructive student reply..."
                      className="flex-1 px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none focus:ring-2 focus:ring-brand-500"
                    />
                    <button
                      onClick={() => handleAddComment(post.id)}
                      className="px-4 py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-xl text-xs font-semibold flex items-center space-x-1"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Reply</span>
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Student Blogs & Healthy Study Habits */}
      {activeTab === 'blogs' && (
        <div className="space-y-6">
          <div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">
              Productivity Tips & Student Wellness Articles
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Practical guides on cognitive performance, stress relief, and healthy college life.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {initialBlogs.map((blog) => (
              <div
                key={blog.id}
                className="p-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm flex flex-col justify-between space-y-4 hover:shadow-lg transition-all"
              >
                <div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
                    <span className="font-bold text-brand-600 dark:text-brand-400 uppercase tracking-wider">
                      {blog.category}
                    </span>
                    <span>{blog.readTime}</span>
                  </div>

                  <h4 className="font-bold text-base text-slate-900 dark:text-slate-100 line-clamp-2">
                    {blog.title}
                  </h4>

                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">
                    {blog.snippet}
                  </p>

                  <div className="flex flex-wrap gap-1.5 mt-4">
                    {blog.tags.map((t) => (
                      <span
                        key={t}
                        className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
                  <span>By {blog.author}</span>
                  <span>{blog.date}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Create Post Modal */}
      <Modal
        isOpen={isPostModalOpen}
        onClose={() => setIsPostModalOpen(false)}
        title="Start a Student Discussion"
      >
        <form onSubmit={handleCreatePost} className="space-y-4 text-left">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Discussion Topic / Headline *
            </label>
            <input
              type="text"
              required
              value={postTitle}
              onChange={(e) => setPostTitle(e.target.value)}
              placeholder="e.g. Forming an algorithms practice group for Google SDE interviews"
              className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Category Tag
            </label>
            <select
              value={postTag}
              onChange={(e) => setPostTag(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
            >
              <option value="Study Groups">Study Groups</option>
              <option value="Career Advice">Career Advice</option>
              <option value="Campus Hacks">Campus Hacks</option>
              <option value="Course Reviews">Course Reviews</option>
              <option value="Housing & Roommates">Housing & Roommates</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Message Body *
            </label>
            <textarea
              rows={4}
              required
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              placeholder="Share details, meeting times, library study room numbers, or advice..."
              className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsPostModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-brand-600 hover:bg-brand-500 rounded-xl shadow-sm"
            >
              Publish Post
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
