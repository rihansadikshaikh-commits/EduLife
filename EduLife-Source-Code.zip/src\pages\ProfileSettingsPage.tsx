import React, { useState } from 'react';
import {
  Settings,
  User,
  Bell,
  Moon,
  Sun,
  Download,
  Upload,
  RotateCcw,
  Save,
  CheckCircle2,
  Clock,
  Sparkles,
  ShieldAlert
} from 'lucide-react';
import { useAppData } from '../context/AppDataContext';
import { useTheme } from '../context/ThemeContext';
import { useToast } from '../context/ToastContext';
import { StudentProfile } from '../types';

export const ProfileSettingsPage: React.FC = () => {
  const { profile, updateProfile, resetAllData } = useAppData();
  const { theme, setTheme } = useTheme();
  const { showToast } = useToast();

  const [formData, setFormData] = useState<StudentProfile>(profile);
  const [resetConfirmOpen, setResetConfirmOpen] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile(formData);
    showToast('Profile and study preferences updated!', 'success');
  };

  const handleExportData = () => {
    const dataToExport = {
      profile,
      tasks: localStorage.getItem('edulife_tasks'),
      notes: localStorage.getItem('edulife_notes'),
      assignments: localStorage.getItem('edulife_assignments'),
      exams: localStorage.getItem('edulife_exams'),
      timetable: localStorage.getItem('edulife_timetable'),
      budget: localStorage.getItem('edulife_budget'),
      exportDate: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `edulife-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Exported EduLife backup JSON successfully!', 'success');
  };

  const handleResetData = () => {
    resetAllData();
    showToast('Platform reset to default realistic student data!', 'info');
    setResetConfirmOpen(false);
    setTimeout(() => {
      window.location.reload();
    }, 500);
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2.5">
          <Settings className="w-8 h-8 text-brand-600" />
          Profile & Application Settings
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          Customize your student identity, daily study targets, theme preferences, and data backups.
        </p>
      </div>

      <form onSubmit={handleSaveProfile} className="space-y-8">
        {/* Profile Card */}
        <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex items-center space-x-4 pb-6 border-b border-slate-100 dark:border-slate-800">
            <img
              src={formData.avatarUrl}
              alt={formData.name}
              className="w-16 h-16 rounded-2xl object-cover ring-4 ring-brand-500/20 shadow-md"
            />
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                Student Identity
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                This information personalizes your dashboard and community posts.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3.5 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Student Email *
              </label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3.5 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                College / University
              </label>
              <input
                type="text"
                value={formData.college}
                onChange={(e) => setFormData({ ...formData, college: e.target.value })}
                className="w-full px-3.5 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Degree / Major
              </label>
              <input
                type="text"
                value={formData.degree}
                onChange={(e) => setFormData({ ...formData, degree: e.target.value })}
                className="w-full px-3.5 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Semester / Class Standing
              </label>
              <input
                type="text"
                value={formData.semester}
                onChange={(e) => setFormData({ ...formData, semester: e.target.value })}
                className="w-full px-3.5 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Avatar Image URL
              </label>
              <input
                type="url"
                value={formData.avatarUrl}
                onChange={(e) => setFormData({ ...formData, avatarUrl: e.target.value })}
                className="w-full px-3.5 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Study Targets & Goals */}
        <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex items-center space-x-3 pb-4 border-b border-slate-100 dark:border-slate-800">
            <Clock className="w-6 h-6 text-violet-500" />
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Daily Study Target Hours
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Adjusts your target guideline in the dashboard weekly progress chart.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Daily Goal:
              </span>
              <span className="text-lg font-extrabold text-brand-600 dark:text-brand-400">
                {formData.dailyStudyGoalHours} Hours / Day
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="10"
              step="0.5"
              value={formData.dailyStudyGoalHours}
              onChange={(e) =>
                setFormData({ ...formData, dailyStudyGoalHours: Number(e.target.value) })
              }
              className="w-full accent-brand-600"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-semibold">
              <span>1 Hour (Light)</span>
              <span>4.5 Hours (Standard)</span>
              <span>10 Hours (Intense)</span>
            </div>
          </div>
        </div>

        {/* Theme & Display Mode */}
        <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex items-center space-x-3 pb-4 border-b border-slate-100 dark:border-slate-800">
            <Sparkles className="w-6 h-6 text-amber-500" />
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Theme & Interface Appearance
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Toggle between bright crisp light mode and eye-friendly dark mode.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div
              onClick={() => setTheme('light')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-center space-x-3 ${
                theme === 'light'
                  ? 'border-brand-500 bg-brand-50/50 shadow-sm'
                  : 'border-slate-200 dark:border-slate-700 hover:border-slate-300'
              }`}
            >
              <div className="p-2.5 rounded-xl bg-amber-100 text-amber-700">
                <Sun className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900">Light Mode</h4>
                <p className="text-[11px] text-slate-500">Bright and clean</p>
              </div>
            </div>

            <div
              onClick={() => setTheme('dark')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-center space-x-3 ${
                theme === 'dark'
                  ? 'border-brand-500 bg-slate-800 shadow-sm'
                  : 'border-slate-200 dark:border-slate-700 hover:border-slate-300'
              }`}
            >
              <div className="p-2.5 rounded-xl bg-violet-900/50 text-violet-300">
                <Moon className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Dark Mode</h4>
                <p className="text-[11px] text-slate-400">Soft for late night study</p>
              </div>
            </div>
          </div>
        </div>

        {/* Notifications and Reminders */}
        <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center space-x-3 pb-4 border-b border-slate-100 dark:border-slate-800">
            <Bell className="w-6 h-6 text-brand-500" />
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Reminders & Alerts
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Control notifications for pending assignments and upcoming exams.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <label className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 cursor-pointer">
              <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                Assignment Deadline Push Reminders (24h before due date)
              </span>
              <input
                type="checkbox"
                checked={formData.notificationsEnabled}
                onChange={(e) =>
                  setFormData({ ...formData, notificationsEnabled: e.target.checked })
                }
                className="w-4 h-4 accent-brand-600 rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 cursor-pointer">
              <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                Midterm & Final Exam Countdown Alerts (7 days & 1 day before)
              </span>
              <input
                type="checkbox"
                checked={formData.examRemindersEnabled}
                onChange={(e) =>
                  setFormData({ ...formData, examRemindersEnabled: e.target.checked })
                }
                className="w-4 h-4 accent-brand-600 rounded"
              />
            </label>
          </div>
        </div>

        {/* Submit Profile Changes */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="flex items-center space-x-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-brand-600 to-violet-600 hover:from-brand-500 hover:to-violet-500 text-white font-semibold text-sm shadow-md shadow-brand-500/20 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>Save Preferences</span>
          </button>
        </div>
      </form>

      {/* Data Management Section */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
            Data Storage & System Operations
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            All your coursework, notes, and schedules are stored securely in your browser's localStorage.
          </p>
        </div>

        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            onClick={handleExportData}
            className="flex items-center space-x-2 px-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 transition-colors"
          >
            <Download className="w-4 h-4 text-brand-600" />
            <span>Export Data as JSON</span>
          </button>

          <button
            type="button"
            onClick={() => setResetConfirmOpen(true)}
            className="flex items-center space-x-2 px-4 py-2.5 rounded-2xl border border-rose-200 dark:border-rose-900/50 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-semibold text-rose-600 dark:text-rose-400 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset Demo Data</span>
          </button>
        </div>

        {resetConfirmOpen && (
          <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-300 dark:border-rose-800 text-xs space-y-3">
            <div className="flex items-center space-x-2 text-rose-800 dark:text-rose-200 font-bold">
              <ShieldAlert className="w-4 h-4 text-rose-600" />
              <span>Confirm Data Reset</span>
            </div>
            <p className="text-slate-600 dark:text-slate-300">
              Are you sure? This will restore the platform to the initial sample coursework, tasks, notes, and events.
            </p>
            <div className="flex space-x-2">
              <button
                onClick={handleResetData}
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-semibold rounded-xl"
              >
                Yes, Reset Everything
              </button>
              <button
                onClick={() => setResetConfirmOpen(false)}
                className="px-4 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-semibold rounded-xl"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
