import React from 'react';
import { Link } from 'react-router-dom';
import {
  FileText,
  Calendar,
  Timer,
  BookOpen,
  Briefcase,
  Users,
  Sparkles,
  ChevronRight
} from 'lucide-react';

const TOOLS = [
  {
    title: 'Smart Notes',
    description: 'Markdown notes, cheatsheets & tags',
    path: '/notes',
    icon: FileText,
    gradient: 'from-blue-500/15 to-indigo-500/15 text-blue-600 dark:text-blue-400',
    count: '4 Notes'
  },
  {
    title: 'Timetable',
    description: 'Weekly schedule & class locations',
    path: '/planner',
    icon: Calendar,
    gradient: 'from-purple-500/15 to-pink-500/15 text-purple-600 dark:text-purple-400',
    count: '8 Classes'
  },
  {
    title: 'Pomodoro Timer',
    description: 'Deep focus intervals & audio chime',
    path: '/planner',
    icon: Timer,
    gradient: 'from-emerald-500/15 to-teal-500/15 text-emerald-600 dark:text-emerald-400',
    count: '25m Focus'
  },
  {
    title: 'Education Resources',
    description: 'Cheat sheets, tools & scholarships',
    path: '/resources',
    icon: BookOpen,
    gradient: 'from-amber-500/15 to-orange-500/15 text-amber-600 dark:text-amber-400',
    count: '7 Materials'
  },
  {
    title: 'Career & Internships',
    description: 'Listings, resume review & interviews',
    path: '/career',
    icon: Briefcase,
    gradient: 'from-rose-500/15 to-red-500/15 text-rose-600 dark:text-rose-400',
    count: '4 Openings'
  },
  {
    title: 'Campus Community',
    description: 'Clubs, hackathons & discussion feeds',
    path: '/community',
    icon: Users,
    gradient: 'from-cyan-500/15 to-sky-500/15 text-cyan-600 dark:text-cyan-400',
    count: '4 Clubs'
  }
];

export const QuickAccessCards: React.FC = () => {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-brand-500" />
          Quick Access Study Tools
        </h3>
        <span className="text-xs text-slate-500 dark:text-slate-400">Everything in one place</span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {TOOLS.map((tool) => {
          const Icon = tool.icon;
          return (
            <Link
              key={tool.title}
              to={tool.path}
              className="p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 hover:shadow-md hover:border-brand-300 dark:hover:border-brand-700 transition-all group flex flex-col justify-between"
            >
              <div>
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform bg-gradient-to-br ${tool.gradient}`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
                  {tool.title}
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-snug">
                  {tool.description}
                </p>
              </div>

              <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-[10px] font-semibold text-slate-400">
                <span>{tool.count}</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-1 group-hover:text-brand-500 transition-all" />
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
};
