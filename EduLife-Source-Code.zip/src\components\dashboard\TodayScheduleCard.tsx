import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, MapPin, ArrowRight } from 'lucide-react';
import { useAppData } from '../../context/AppDataContext';

export const TodayScheduleCard: React.FC = () => {
  const { timetable } = useAppData();

  // Get today's day name
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'] as const;
  const todayDay = dayNames[new Date().getDay()];
  const fallbackDay = todayDay === 'Sunday' ? 'Monday' : todayDay;

  const todayClasses = timetable
    .filter((slot) => slot.day === fallbackDay)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-brand-600 dark:text-brand-400">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Today's Schedule
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {fallbackDay} • {todayClasses.length} lectures scheduled
              </p>
            </div>
          </div>
          <Link
            to="/planner"
            className="text-xs font-semibold text-brand-600 dark:text-brand-400 hover:text-brand-500 flex items-center space-x-1"
          >
            <span>Full Week</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {todayClasses.length === 0 ? (
          <div className="text-center py-8 text-slate-400">
            <p className="text-xs font-medium">No classes today. Perfect day for revisions!</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {todayClasses.slice(0, 3).map((slot) => (
              <div
                key={slot.id}
                className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex items-center justify-between hover:bg-slate-100/70 dark:hover:bg-slate-800 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-1.5 h-9 rounded-full bg-brand-500" />
                  <div>
                    <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      {slot.subject}
                    </h4>
                    <div className="flex items-center space-x-3 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      <span className="flex items-center space-x-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>{slot.startTime} - {slot.endTime}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        <span>{slot.room}</span>
                      </span>
                    </div>
                  </div>
                </div>
                <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-700 px-2 py-1 rounded-lg border border-slate-200/50 dark:border-slate-600">
                  {slot.instructor}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
        <span>Campus Attendance: 92%</span>
        <span className="text-emerald-600 dark:text-emerald-400 font-semibold">Good Standing</span>
      </div>
    </div>
  );
};
