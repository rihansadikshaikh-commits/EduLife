import React, { useState } from 'react';
import { Plus, Trash2, Clock, MapPin, User, Calendar } from 'lucide-react';
import { useAppData } from '../../context/AppDataContext';
import { useToast } from '../../context/ToastContext';
import { Modal } from '../common/Modal';
import { TimetableSlot } from '../../types';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'] as const;

const COLOR_OPTIONS = [
  { label: 'Blue', class: 'bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-900/40 dark:text-blue-300 dark:border-blue-700' },
  { label: 'Purple', class: 'bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-900/40 dark:text-purple-300 dark:border-purple-700' },
  { label: 'Green', class: 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-900/40 dark:text-emerald-300 dark:border-emerald-700' },
  { label: 'Amber', class: 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-900/40 dark:text-amber-300 dark:border-amber-700' },
  { label: 'Rose', class: 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-900/40 dark:text-rose-300 dark:border-rose-700' }
];

export const TimetableGrid: React.FC = () => {
  const { timetable, addTimetableSlot, deleteTimetableSlot } = useAppData();
  const { showToast } = useToast();

  const [selectedDay, setSelectedDay] = useState<typeof DAYS[number]>('Monday');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Form state
  const [subject, setSubject] = useState('');
  const [day, setDay] = useState<typeof DAYS[number]>('Monday');
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('10:30');
  const [room, setRoom] = useState('');
  const [instructor, setInstructor] = useState('');
  const [colorClass, setColorClass] = useState(COLOR_OPTIONS[0].class);

  const handleAddSlot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim()) {
      showToast('Please enter subject title', 'error');
      return;
    }

    addTimetableSlot({
      subject,
      day,
      startTime,
      endTime,
      room: room || 'Room TBD',
      instructor: instructor || 'Staff',
      color: colorClass
    });

    showToast(`Added ${subject} to ${day} schedule!`, 'success');
    setIsAddModalOpen(false);
    setSubject('');
    setRoom('');
    setInstructor('');
  };

  const filteredSlots = timetable.filter((slot) => slot.day === selectedDay);

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-brand-500" />
            Class Timetable & Schedule
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Keep track of lecture halls, lab sections, and instructor timings.
          </p>
        </div>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center space-x-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-brand-600 hover:bg-brand-500 rounded-xl shadow-sm transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Class Slot</span>
        </button>
      </div>

      {/* Day of Week Selector */}
      <div className="flex items-center space-x-1.5 overflow-x-auto pb-2 mb-6 border-b border-slate-100 dark:border-slate-800">
        {DAYS.map((d) => {
          const count = timetable.filter((slot) => slot.day === d).length;
          const isSelected = selectedDay === d;
          return (
            <button
              key={d}
              onClick={() => setSelectedDay(d)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                isSelected
                  ? 'bg-brand-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <span>{d}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  isSelected ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Class List for the selected day */}
      {filteredSlots.length === 0 ? (
        <div className="text-center py-12 text-slate-400">
          <p className="text-sm font-medium">No classes scheduled on {selectedDay}!</p>
          <p className="text-xs text-slate-500 mt-1">Enjoy your free time or schedule a study block.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {filteredSlots
            .sort((a, b) => a.startTime.localeCompare(b.startTime))
            .map((slot) => (
              <div
                key={slot.id}
                className={`p-4 rounded-2xl border transition-all hover:shadow-md relative group flex flex-col justify-between ${slot.color}`}
              >
                <div>
                  <div className="flex items-start justify-between">
                    <h4 className="font-bold text-sm tracking-tight">{slot.subject}</h4>
                    <button
                      onClick={() => {
                        deleteTimetableSlot(slot.id);
                        showToast(`Removed class from ${slot.day}`, 'info');
                      }}
                      className="opacity-0 group-hover:opacity-100 p-1 rounded-lg text-slate-400 hover:text-rose-600 transition-opacity"
                      title="Remove class"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center space-x-1.5 text-xs font-semibold mt-2">
                    <Clock className="w-3.5 h-3.5 opacity-70" />
                    <span>
                      {slot.startTime} - {slot.endTime}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs mt-3 pt-2.5 border-t border-black/5 dark:border-white/10 opacity-90">
                  <div className="flex items-center space-x-1">
                    <MapPin className="w-3 h-3 opacity-75" />
                    <span>{slot.room}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <User className="w-3 h-3 opacity-75" />
                    <span>{slot.instructor}</span>
                  </div>
                </div>
              </div>
            ))}
        </div>
      )}

      {/* Add Slot Modal */}
      <Modal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} title="Add Timetable Slot">
        <form onSubmit={handleAddSlot} className="space-y-4 text-left">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Subject Name *
            </label>
            <input
              type="text"
              required
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="e.g. Distributed Systems"
              className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-brand-500 outline-none"
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Day
              </label>
              <select
                value={day}
                onChange={(e) => setDay(e.target.value as typeof DAYS[number])}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              >
                {DAYS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Start Time
              </label>
              <input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                End Time
              </label>
              <input
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Classroom / Lab
              </label>
              <input
                type="text"
                value={room}
                onChange={(e) => setRoom(e.target.value)}
                placeholder="e.g. Science 304"
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Instructor
              </label>
              <input
                type="text"
                value={instructor}
                onChange={(e) => setInstructor(e.target.value)}
                placeholder="e.g. Dr. Alan Vance"
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Card Color Accent
            </label>
            <div className="flex gap-2">
              {COLOR_OPTIONS.map((opt) => (
                <button
                  type="button"
                  key={opt.label}
                  onClick={() => setColorClass(opt.class)}
                  className={`px-3 py-1.5 text-xs rounded-lg font-medium border transition-all ${opt.class} ${
                    colorClass === opt.class ? 'ring-2 ring-brand-500 scale-105' : 'opacity-70'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-brand-600 hover:bg-brand-500 rounded-xl shadow-sm"
            >
              Save Class Slot
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
