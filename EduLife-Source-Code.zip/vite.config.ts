import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          'react-vendor': ['react', 'react-dom', 'react-router-dom'],
          'ui-charts': ['recharts'],
          'ui-icons': ['lucide-react']
        }
      }
    }
  },
  server: {
    port: 5173,
    host: true
  }
});
