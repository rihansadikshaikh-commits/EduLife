import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Task,
  Note,
  Assignment,
  Exam,
  TimetableSlot,
  SubjectProgress,
  ResourceItem,
  CampusEvent,
  StudentClub,
  CommunityPost,
  Internship,
  BudgetItem,
  StudentProfile,
  AssignmentStatus
} from '../types';
import {
  initialTasks,
  initialNotes,
  initialAssignments,
  initialExams,
  initialTimetable,
  initialSubjectProgress,
  initialWeeklyStudyData,
  initialResources,
  initialEvents,
  initialClubs,
  initialPosts,
  initialInternships,
  initialBudgetItems,
  initialProfile
} from '../data/initialData';

interface WeeklyStudyDay {
  day: string;
  hours: number;
  target: number;
  pomodoros: number;
}

interface AppDataContextType {
  // Tasks
  tasks: Task[];
  addTask: (task: Omit<Task, 'id'>) => void;
  toggleTask: (id: string) => void;
  updateTask: (task: Task) => void;
  deleteTask: (id: string) => void;

  // Notes
  notes: Note[];
  addNote: (note: Omit<Note, 'id' | 'updatedAt'>) => void;
  updateNote: (note: Note) => void;
  deleteNote: (id: string) => void;
  togglePinNote: (id: string) => void;

  // Assignments
  assignments: Assignment[];
  addAssignment: (assignment: Omit<Assignment, 'id'>) => void;
  updateAssignment: (assignment: Assignment) => void;
  deleteAssignment: (id: string) => void;
  updateAssignmentStatus: (id: string, status: AssignmentStatus) => void;

  // Exams
  exams: Exam[];
  addExam: (exam: Omit<Exam, 'id'>) => void;
  updateExam: (exam: Exam) => void;
  deleteExam: (id: string) => void;
  toggleExamTopic: (examId: string, topicId: string) => void;

  // Timetable
  timetable: TimetableSlot[];
  addTimetableSlot: (slot: Omit<TimetableSlot, 'id'>) => void;
  deleteTimetableSlot: (id: string) => void;

  // Subject Progress
  subjectProgress: SubjectProgress[];
  updateSubjectProgress: (progress: SubjectProgress) => void;

  // Study Stats & Pomodoro
  weeklyStudyData: WeeklyStudyDay[];
  recordStudySession: (minutes: number) => void;

  // Resources
  resources: ResourceItem[];
  toggleBookmarkResource: (id: string) => void;
  addResource: (res: Omit<ResourceItem, 'id'>) => void;

  // Campus Events
  events: CampusEvent[];
  toggleRegisterEvent: (id: string) => void;

  // Student Clubs
  clubs: StudentClub[];
  toggleJoinClub: (id: string) => void;

  // Community Posts
  posts: CommunityPost[];
  addPost: (post: Omit<CommunityPost, 'id' | 'likes' | 'commentsCount' | 'timestamp'>) => void;
  toggleLikePost: (id: string) => void;
  addCommentToPost: (postId: string, commentText: string) => void;

  // Internships
  internships: Internship[];
  toggleSaveInternship: (id: string) => void;

  // Budget
  budget: BudgetItem[];
  addBudgetItem: (item: Omit<BudgetItem, 'id'>) => void;
  deleteBudgetItem: (id: string) => void;

  // Profile
  profile: StudentProfile;
  updateProfile: (profile: StudentProfile) => void;

  // Global reset
  resetAllData: () => void;
}

const AppDataContext = createContext<AppDataContextType | undefined>(undefined);

const loadFromStorage = <T,>(key: string, fallback: T): T => {
  try {
    const item = localStorage.getItem(`edulife_${key}`);
    return item ? JSON.parse(item) : fallback;
  } catch (error) {
    console.error(`Error loading ${key} from localStorage:`, error);
    return fallback;
  }
};

const saveToStorage = <T,>(key: string, value: T) => {
  try {
    localStorage.setItem(`edulife_${key}`, JSON.stringify(value));
  } catch (error) {
    console.error(`Error saving ${key} to localStorage:`, error);
  }
};

export const AppDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tasks, setTasks] = useState<Task[]>(() => loadFromStorage('tasks', initialTasks));
  const [notes, setNotes] = useState<Note[]>(() => loadFromStorage('notes', initialNotes));
  const [assignments, setAssignments] = useState<Assignment[]>(() =>
    loadFromStorage('assignments', initialAssignments)
  );
  const [exams, setExams] = useState<Exam[]>(() => loadFromStorage('exams', initialExams));
  const [timetable, setTimetable] = useState<TimetableSlot[]>(() =>
    loadFromStorage('timetable', initialTimetable)
  );
  const [subjectProgress, setSubjectProgress] = useState<SubjectProgress[]>(() =>
    loadFromStorage('subjects', initialSubjectProgress)
  );
  const [weeklyStudyData, setWeeklyStudyData] = useState<WeeklyStudyDay[]>(() =>
    loadFromStorage('weekly_study', initialWeeklyStudyData)
  );
  const [resources, setResources] = useState<ResourceItem[]>(() =>
    loadFromStorage('resources', initialResources)
  );
  const [events, setEvents] = useState<CampusEvent[]>(() => loadFromStorage('events', initialEvents));
  const [clubs, setClubs] = useState<StudentClub[]>(() => loadFromStorage('clubs', initialClubs));
  const [posts, setPosts] = useState<CommunityPost[]>(() => loadFromStorage('posts', initialPosts));
  const [internships, setInternships] = useState<Internship[]>(() =>
    loadFromStorage('internships', initialInternships)
  );
  const [budget, setBudget] = useState<BudgetItem[]>(() => loadFromStorage('budget', initialBudgetItems));
  const [profile, setProfile] = useState<StudentProfile>(() => loadFromStorage('profile', initialProfile));

  // Sync to localStorage
  useEffect(() => saveToStorage('tasks', tasks), [tasks]);
  useEffect(() => saveToStorage('notes', notes), [notes]);
  useEffect(() => saveToStorage('assignments', assignments), [assignments]);
  useEffect(() => saveToStorage('exams', exams), [exams]);
  useEffect(() => saveToStorage('timetable', timetable), [timetable]);
  useEffect(() => saveToStorage('subjects', subjectProgress), [subjectProgress]);
  useEffect(() => saveToStorage('weekly_study', weeklyStudyData), [weeklyStudyData]);
  useEffect(() => saveToStorage('resources', resources), [resources]);
  useEffect(() => saveToStorage('events', events), [events]);
  useEffect(() => saveToStorage('clubs', clubs), [clubs]);
  useEffect(() => saveToStorage('posts', posts), [posts]);
  useEffect(() => saveToStorage('internships', internships), [internships]);
  useEffect(() => saveToStorage('budget', budget), [budget]);
  useEffect(() => saveToStorage('profile', profile), [profile]);

  // Tasks actions
  const addTask = (newTask: Omit<Task, 'id'>) => {
    const task: Task = { ...newTask, id: 't-' + Date.now() };
    setTasks((prev) => [task, ...prev]);
  };

  const toggleTask = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const nextCompleted = !t.completed;
          if (nextCompleted) {
            try {
              confetti({
                particleCount: 50,
                spread: 60,
                origin: { y: 0.8 }
              });
            } catch {
              // ignore
            }
          }
          return { ...t, completed: nextCompleted };
        }
        return t;
      })
    );
  };

  const updateTask = (updated: Task) => {
    setTasks((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));
  };

  const deleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  // Notes actions
  const addNote = (newNote: Omit<Note, 'id' | 'updatedAt'>) => {
    const note: Note = {
      ...newNote,
      id: 'n-' + Date.now(),
      updatedAt: new Date().toISOString()
    };
    setNotes((prev) => [note, ...prev]);
  };

  const updateNote = (updated: Note) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === updated.id ? { ...updated, updatedAt: new Date().toISOString() } : n))
    );
  };

  const deleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
  };

  const togglePinNote = (id: string) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, pinned: !n.pinned, updatedAt: new Date().toISOString() } : n))
    );
  };

  // Assignments actions
  const addAssignment = (newAssignment: Omit<Assignment, 'id'>) => {
    const item: Assignment = { ...newAssignment, id: 'a-' + Date.now() };
    setAssignments((prev) => [item, ...prev]);
  };

  const updateAssignment = (updated: Assignment) => {
    setAssignments((prev) => prev.map((a) => (a.id === updated.id ? updated : a)));
  };

  const deleteAssignment = (id: string) => {
    setAssignments((prev) => prev.filter((a) => a.id !== id));
  };

  const updateAssignmentStatus = (id: string, status: AssignmentStatus) => {
    setAssignments((prev) => {
      const updated = prev.map((a) => (a.id === id ? { ...a, status } : a));
      if (status === 'submitted') {
        try {
          confetti({ particleCount: 70, spread: 70, origin: { y: 0.7 } });
        } catch {
          // ignore
        }
      }
      return updated;
    });
  };

  // Exams actions
  const addExam = (newExam: Omit<Exam, 'id'>) => {
    const item: Exam = { ...newExam, id: 'e-' + Date.now() };
    setExams((prev) => [...prev, item]);
  };

  const updateExam = (updated: Exam) => {
    setExams((prev) => prev.map((e) => (e.id === updated.id ? updated : e)));
  };

  const deleteExam = (id: string) => {
    setExams((prev) => prev.filter((e) => e.id !== id));
  };

  const toggleExamTopic = (examId: string, topicId: string) => {
    setExams((prev) =>
      prev.map((exam) => {
        if (exam.id === examId) {
          const updatedTopics = exam.topics.map((t) =>
            t.id === topicId ? { ...t, completed: !t.completed } : t
          );
          return { ...exam, topics: updatedTopics };
        }
        return exam;
      })
    );
  };

  // Timetable
  const addTimetableSlot = (slot: Omit<TimetableSlot, 'id'>) => {
    const item: TimetableSlot = { ...slot, id: 'tt-' + Date.now() };
    setTimetable((prev) => [...prev, item]);
  };

  const deleteTimetableSlot = (id: string) => {
    setTimetable((prev) => prev.filter((s) => s.id !== id));
  };

  // Subject Progress
  const updateSubjectProgress = (progress: SubjectProgress) => {
    setSubjectProgress((prev) => prev.map((s) => (s.id === progress.id ? progress : s)));
  };

  // Study Session Record
  const recordStudySession = (minutes: number) => {
    const hours = Number((minutes / 60).toFixed(1));
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const currentDayName = dayNames[new Date().getDay()];

    setWeeklyStudyData((prev) =>
      prev.map((d) => {
        if (d.day === currentDayName) {
          return {
            ...d,
            hours: Number((d.hours + hours).toFixed(1)),
            pomodoros: d.pomodoros + 1
          };
        }
        return d;
      })
    );
  };

  // Resources
  const toggleBookmarkResource = (id: string) => {
    setResources((prev) =>
      prev.map((r) => (r.id === id ? { ...r, isBookmarked: !r.isBookmarked } : r))
    );
  };

  const addResource = (res: Omit<ResourceItem, 'id'>) => {
    const item: ResourceItem = { ...res, id: 'res-' + Date.now() };
    setResources((prev) => [item, ...prev]);
  };

  // Events
  const toggleRegisterEvent = (id: string) => {
    setEvents((prev) =>
      prev.map((e) => {
        if (e.id === id) {
          const nextRegistered = !e.isRegistered;
          return {
            ...e,
            isRegistered: nextRegistered,
            attendeesCount: nextRegistered ? e.attendeesCount + 1 : e.attendeesCount - 1
          };
        }
        return e;
      })
    );
  };

  // Clubs
  const toggleJoinClub = (id: string) => {
    setClubs((prev) =>
      prev.map((c) => {
        if (c.id === id) {
          const nextJoined = !c.isJoined;
          return {
            ...c,
            isJoined: nextJoined,
            membersCount: nextJoined ? c.membersCount + 1 : c.membersCount - 1
          };
        }
        return c;
      })
    );
  };

  // Posts
  const addPost = (newPost: Omit<CommunityPost, 'id' | 'likes' | 'commentsCount' | 'timestamp'>) => {
    const post: CommunityPost = {
      ...newPost,
      id: 'post-' + Date.now(),
      likes: 0,
      commentsCount: 0,
      timestamp: 'Just now',
      replies: []
    };
    setPosts((prev) => [post, ...prev]);
  };

  const toggleLikePost = (id: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          const isLiked = !p.isLiked;
          return {
            ...p,
            isLiked,
            likes: isLiked ? p.likes + 1 : p.likes - 1
          };
        }
        return p;
      })
    );
  };

  const addCommentToPost = (postId: string, commentText: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          const newReply = {
            id: 'rep-' + Date.now(),
            authorName: profile.name,
            content: commentText,
            timestamp: 'Just now'
          };
          return {
            ...p,
            commentsCount: p.commentsCount + 1,
            replies: [...(p.replies || []), newReply]
          };
        }
        return p;
      })
    );
  };

  // Internships
  const toggleSaveInternship = (id: string) => {
    setInternships((prev) =>
      prev.map((i) => (i.id === id ? { ...i, saved: !i.saved } : i))
    );
  };

  // Budget
  const addBudgetItem = (item: Omit<BudgetItem, 'id'>) => {
    const budgetItem: BudgetItem = { ...item, id: 'b-' + Date.now() };
    setBudget((prev) => [budgetItem, ...prev]);
  };

  const deleteBudgetItem = (id: string) => {
    setBudget((prev) => prev.filter((b) => b.id !== id));
  };

  // Profile
  const updateProfile = (newProfile: StudentProfile) => {
    setProfile(newProfile);
  };

  // Reset
  const resetAllData = () => {
    localStorage.clear();
    setTasks(initialTasks);
    setNotes(initialNotes);
    setAssignments(initialAssignments);
    setExams(initialExams);
    setTimetable(initialTimetable);
    setSubjectProgress(initialSubjectProgress);
    setWeeklyStudyData(initialWeeklyStudyData);
    setResources(initialResources);
    setEvents(initialEvents);
    setClubs(initialClubs);
    setPosts(initialPosts);
    setInternships(initialInternships);
    setBudget(initialBudgetItems);
    setProfile(initialProfile);
  };

  return (
    <AppDataContext.Provider
      value={{
        tasks,
        addTask,
        toggleTask,
        updateTask,
        deleteTask,

        notes,
        addNote,
        updateNote,
        deleteNote,
        togglePinNote,

        assignments,
        addAssignment,
        updateAssignment,
        deleteAssignment,
        updateAssignmentStatus,

        exams,
        addExam,
        updateExam,
        deleteExam,
        toggleExamTopic,

        timetable,
        addTimetableSlot,
        deleteTimetableSlot,

        subjectProgress,
        updateSubjectProgress,

        weeklyStudyData,
        recordStudySession,

        resources,
        toggleBookmarkResource,
        addResource,

        events,
        toggleRegisterEvent,

        clubs,
        toggleJoinClub,

        posts,
        addPost,
        toggleLikePost,
        addCommentToPost,

        internships,
        toggleSaveInternship,

        budget,
        addBudgetItem,
        deleteBudgetItem,

        profile,
        updateProfile,

        resetAllData
      }}
    >
      {children}
    </AppDataContext.Provider>
  );
};

export const useAppData = () => {
  const context = useContext(AppDataContext);
  if (!context) {
    throw new Error('useAppData must be used within an AppDataProvider');
  }
  return context;
};
