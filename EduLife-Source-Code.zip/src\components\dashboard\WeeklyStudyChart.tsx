import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Cell
} from 'recharts';
import { TrendingUp, Clock } from 'lucide-react';
import { useAppData } from '../../context/AppDataContext';
import { useTheme } from '../../context/ThemeContext';

export const WeeklyStudyChart: React.FC = () => {
  const { weeklyStudyData, profile } = useAppData();
  const { theme } = useTheme();

  const totalWeeklyHours = weeklyStudyData.reduce((acc, d) => acc + d.hours, 0);
  const avgHours = Number((totalWeeklyHours / weeklyStudyData.length).toFixed(1));
  const targetMetDays = weeklyStudyData.filter((d) => d.hours >= profile.dailyStudyGoalHours).length;

  const isDark = theme === 'dark';

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-violet-50 dark:bg-violet-950/60 text-violet-600 dark:text-violet-400">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Weekly Study Progress
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Total: <strong className="text-slate-800 dark:text-slate-200">{totalWeeklyHours.toFixed(1)} hrs</strong> • Daily Target: <strong>{profile.dailyStudyGoalHours} hrs</strong>
              </p>
            </div>
          </div>
        </div>

        {/* Mini stats badges */}
        <div className="flex items-center space-x-3 text-xs">
          <div className="px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <span className="text-slate-500">Daily Average:</span>{' '}
            <strong className="text-brand-600 dark:text-brand-400">{avgHours}h</strong>
          </div>
          <div className="px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
            <span>Goals Met: <strong>{targetMetDays}/7 days</strong></span>
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={weeklyStudyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <XAxis
              dataKey="day"
              stroke={isDark ? '#64748b' : '#94a3b8'}
              fontSize={12}
              tickLine={false}
              axisLine={false}
            />
            <YAxis
              stroke={isDark ? '#64748b' : '#94a3b8'}
              fontSize={12}
              tickLine={false}
              axisLine={false}
              unit="h"
            />
            <Tooltip
              cursor={{ fill: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.03)' }}
              contentStyle={{
                backgroundColor: isDark ? '#0f172a' : '#ffffff',
                borderColor: isDark ? '#1e293b' : '#e2e8f0',
                borderRadius: '1rem',
                boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)',
                color: isDark ? '#f8fafc' : '#0f172a',
                fontSize: '12px'
              }}
              formatter={(value: number) => [`${value} Hours`, 'Studied']}
            />
            <ReferenceLine
              y={profile.dailyStudyGoalHours}
              stroke="#8b5cf6"
              strokeDasharray="4 4"
              label={{
                value: `Goal (${profile.dailyStudyGoalHours}h)`,
                position: 'right',
                fill: '#8b5cf6',
                fontSize: 10
              }}
            />
            <Bar dataKey="hours" radius={[8, 8, 4, 4]}>
              {weeklyStudyData.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={entry.hours >= profile.dailyStudyGoalHours ? '#4378f7' : '#93c5fd'}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
        <div className="flex items-center space-x-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-brand-500"></span>
            <span>Target Achieved</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-300 dark:bg-blue-600"></span>
            <span>In Progress</span>
          </span>
        </div>
        <div className="flex items-center gap-1 text-slate-600 dark:text-slate-300 font-medium">
          <Clock className="w-3.5 h-3.5 text-brand-500" />
          <span>Completed 53 Pomodoros this week</span>
        </div>
      </div>
    </div>
  );
};
